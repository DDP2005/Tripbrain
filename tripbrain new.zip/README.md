# TripBrain - Android Trip Planner Application

TripBrain is a smart native Android application built with Kotlin, Jetpack Compose, and Room Database for offline-first trip planning, intelligent worldwide itineraries, hotel budget management, packing lists, expense tracking, and travel booking management.

---

## 🛠️ Tech Stack & Requirements

- **Language**: Kotlin 2.2.10
- **UI Framework**: Jetpack Compose with Material Design 3 (M3)
- **Local Persistence**: Room Database 2.7.0 (with KSP 2.2.10-1.0.29)
- **Architecture**: MVVM (Model-View-ViewModel) + Kotlin Coroutines & StateFlow
- **Build System**: Gradle 8.9 + Android Gradle Plugin 8.7.3
- **Java / JDK**: Java 17
- **SDK Compatibility**:
  - `minSdk`: 24 (Android 7.0+)
  - `compileSdk`: 35 (Android 15)
  - `targetSdk`: 35 (Android 15)

---

## 📁 Project Structure

```text
TripBrain/
├── app/
│   ├── build.gradle.kts
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── java/com/example/
│       │   │   ├── MainActivity.kt
│       │   │   ├── data/
│       │   │   │   ├── database/ (Room DB, DAOs)
│       │   │   │   ├── destination/ (Destination Knowledge Engine)
│       │   │   │   └── model/ (Data entities & domain models)
│       │   │   └── ui/
│       │   │       ├── TripBrainViewModel.kt
│       │   │       ├── components/
│       │   │       ├── create/
│       │   │       ├── home/
│       │   │       ├── plan/
│       │   │       └── theme/
│       │   └── res/
│       └── test/
├── gradle/
│   ├── libs.versions.toml
│   └── wrapper/
│       ├── gradle-wrapper.jar
│       └── gradle-wrapper.properties
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradlew
├── gradlew.bat
└── README.md
```

---

## 🚀 Building & Running Locally

### 1. Using Android Studio
1. Open **Android Studio** (Koala / Ladybug or newer with JDK 17).
2. Choose **File > Open** and select the project root folder.
3. Allow Gradle to sync dependencies.
4. Select a connected physical device or Android Virtual Device (AVD) and click **Run (▶)**.

### 2. Using Command Line / Terminal

#### Build Debug APK:
```bash
./gradlew assembleDebug
```
The output APK is generated at:
```text
app/build/outputs/apk/debug/app-debug.apk
```

#### Run Unit Tests:
```bash
./gradlew testDebugUnitTest
```

---

## ☁️ GitHub Actions Workflow (CI/CD)

To automatically build the APK in GitHub Actions, create `.github/workflows/build.yml`:

```yaml
name: Build Android APK

on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'
          cache: gradle

      - name: Grant execute permission for gradlew
        run: chmod +x gradlew

      - name: Build Debug APK
        run: ./gradlew assembleDebug

      - name: Upload Debug APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: TripBrain-Debug-APK
          path: app/build/outputs/apk/debug/app-debug.apk
```
