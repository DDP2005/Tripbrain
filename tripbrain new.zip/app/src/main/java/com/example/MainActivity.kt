package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.TripBrainViewModel
import com.example.ui.create.CreateTripScreen
import com.example.ui.home.HomeScreen
import com.example.ui.plan.TripDetailScreen
import com.example.ui.theme.TripBrainTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TripBrainTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TripBrainApp()
                }
            }
        }
    }
}

@Composable
fun TripBrainApp(viewModel: TripBrainViewModel = viewModel()) {
    val navController = rememberNavController()

    val allTrips by viewModel.allTrips.collectAsState()
    val currentTrip by viewModel.currentTrip.collectAsState()
    val currentDays by viewModel.currentTripDays.collectAsState()
    val currentActivities by viewModel.currentTripActivities.collectAsState()
    val currentExpenses by viewModel.currentTripExpenses.collectAsState()
    val currentBookings by viewModel.currentTripBookings.collectAsState()
    val currentPacking by viewModel.currentTripPacking.collectAsState()
    val prepItems by viewModel.travelPrepItems.collectAsState()
    val selectedMood by viewModel.selectedMood.collectAsState()
    val quickRecommendations by viewModel.quickRecommendations.collectAsState()

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(
                trips = allTrips,
                onSelectTrip = { tripId ->
                    viewModel.selectTrip(tripId)
                    navController.navigate("detail")
                },
                onCreateNewTrip = {
                    navController.navigate("create")
                },
                onQuickPlanDestination = { destination ->
                    navController.navigate("create?destination=$destination")
                },
                onDeleteTrip = { tripId ->
                    viewModel.deleteTrip(tripId)
                },
                onUpdateTrip = { trip ->
                    viewModel.updateTripDetails(trip)
                }
            )
        }

        composable(
            route = "create?destination={destination}",
            arguments = listOf(
                navArgument("destination") {
                    type = NavType.StringType
                    defaultValue = ""
                }
            )
        ) { backStackEntry ->
            val destinationArg = backStackEntry.arguments?.getString("destination") ?: ""
            CreateTripScreen(
                initialDestination = destinationArg,
                onNavigateBack = { navController.popBackStack() },
                onPlanTrip = { destination, startDateMillis, endDateMillis, totalBudget, currencyCode, currencySymbol, travellers, styles ->
                    viewModel.createAndPlanTrip(
                        destination = destination,
                        startDateMillis = startDateMillis,
                        endDateMillis = endDateMillis,
                        totalBudget = totalBudget,
                        currencyCode = currencyCode,
                        currencySymbol = currencySymbol,
                        travellers = travellers,
                        selectedStyles = styles,
                        onSuccess = {
                            navController.navigate("detail") {
                                popUpTo("home")
                            }
                        }
                    )
                }
            )
        }

        composable("detail") {
            val trip = currentTrip
            if (trip != null) {
                TripDetailScreen(
                    trip = trip,
                    days = currentDays,
                    activities = currentActivities,
                    expenses = currentExpenses,
                    bookings = currentBookings,
                    packingItems = currentPacking,
                    prepItems = prepItems,
                    selectedMood = selectedMood,
                    quickRecommendations = quickRecommendations,
                    onNavigateBack = { navController.popBackStack() },
                    onUpdateHotelBudget = { newBudget -> viewModel.updateHotelBudget(newBudget) },
                    onSelectMood = { mood -> viewModel.selectMood(mood) },
                    onToggleVisited = { act -> viewModel.toggleActivityVisited(act) },
                    onAddActivity = { act -> viewModel.addActivity(act) },
                    onUpdateActivity = { act -> viewModel.updateActivity(act) },
                    onDeleteActivity = { act -> viewModel.deleteActivity(act) },
                    onMoveActivity = { act, targetDay -> viewModel.moveActivityToDay(act, targetDay) },
                    onAddExpense = { cat, amt, desc -> viewModel.addExpense(cat, amt, desc) },
                    onDeleteExpense = { exp -> viewModel.deleteExpense(exp) },
                    onAddBooking = { type, title, ref, time, loc, price, notes ->
                        viewModel.addBooking(type, title, ref, time, loc, price, notes)
                    },
                    onDeleteBooking = { booking -> viewModel.deleteBooking(booking) },
                    onTogglePackingItem = { item -> viewModel.togglePackingItem(item) },
                    onAddPackingItem = { name, cat -> viewModel.addPackingItem(name, cat) },
                    onDeletePackingItem = { item -> viewModel.deletePackingItem(item) },
                    onUpdateTrip = { updated -> viewModel.updateTripDetails(updated) },
                    onDeleteTrip = { tripId ->
                        viewModel.deleteTrip(tripId)
                        navController.popBackStack()
                    }
                )
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        }
    }
}
