package com.example.data.destination

import com.example.data.model.CurrencyInfo

data class DestinationSpot(
    val name: String,
    val category: String,
    val priorityBadge: String, // "⭐ MUST VISIT", "🔥 VERY POPULAR", "👍 WORTH VISITING", "📸 PHOTO SPOT", "💎 HIDDEN GEM"
    val zone: String,
    val durationMinutes: Int,
    val estimatedCostUSD: Double,
    val description: String,
    val tags: List<String>,
    val bestTimeOfDay: String = "Morning", // "Morning", "Afternoon", "Sunset", "Evening", "Night"
    val nearbySuggestions: List<String>
)

data class DestinationData(
    val id: String,
    val name: String,
    val country: String,
    val region: String,
    val localCurrency: CurrencyInfo,
    val typicalDailyCostUSD: Double,
    val isInternationalForINR: Boolean,
    val spots: List<DestinationSpot>,
    val highlights: List<String>,
    val bestSeasons: String
)

object DestinationKnowledgeEngine {

    val CURRENCIES = listOf(
        CurrencyInfo("INR", "Indian Rupee", "₹", 86.5),
        CurrencyInfo("USD", "US Dollar", "$", 1.0),
        CurrencyInfo("EUR", "Euro", "€", 0.92),
        CurrencyInfo("GBP", "British Pound", "£", 0.78),
        CurrencyInfo("AED", "UAE Dirham", "د.إ", 3.67),
        CurrencyInfo("JPY", "Japanese Yen", "¥", 152.0),
        CurrencyInfo("THB", "Thai Baht", "฿", 35.5),
        CurrencyInfo("IDR", "Indonesian Rupiah", "Rp", 15800.0),
        CurrencyInfo("SGD", "Singapore Dollar", "S$", 1.34),
        CurrencyInfo("CHF", "Swiss Franc", "CHF", 0.88),
        CurrencyInfo("AUD", "Australian Dollar", "A$", 1.52),
        CurrencyInfo("CAD", "Canadian Dollar", "C$", 1.38)
    )

    private val DESTINATIONS = listOf(
        DestinationData(
            id = "goa",
            name = "Goa",
            country = "India",
            region = "South Asia",
            localCurrency = CurrencyInfo("INR", "Indian Rupee", "₹", 86.5),
            typicalDailyCostUSD = 45.0,
            isInternationalForINR = false,
            bestSeasons = "Nov - Mar (Pleasant beach breeze & lively shacks)",
            highlights = listOf("Sun-kissed beaches", "Portuguese colonial quarters", "Vibrant sunset beach clubs", "Spice plantations"),
            spots = listOf(
                DestinationSpot(
                    name = "Baga Beach & Coastal Shacks",
                    category = "🏖️ Beach & Watersports",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "North Goa (Calangute-Baga)",
                    durationMinutes = 150,
                    estimatedCostUSD = 15.0,
                    description = "Famous vibrant golden beach packed with water sports, beach cafes, and seaside relaxation.",
                    tags = listOf("Beach", "Relaxed", "Activities", "Cafés", "Mixed"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🍴 Britto's Seafood Shack", "☕ Infantaria Café & Bakery", "🎉 Tito's & Mambo's Lane", "🛍️ Calangute Beach Road Market")
                ),
                DestinationSpot(
                    name = "Chapora Fort & Sunset Viewpoint",
                    category = "🌅 Sunset & History",
                    priorityBadge = "📸 PHOTO SPOT",
                    zone = "North Goa (Vagator)",
                    durationMinutes = 90,
                    estimatedCostUSD = 2.0,
                    description = "Iconic 17th-century red laterite fort offering panoramic 360-degree vistas over Vagator beach and the Arabian Sea.",
                    tags = listOf("Sightseeing", "History", "Photography", "Sunset spot", "Romantic"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("☕ Thalassa Greek Restaurant", "🍹 Antares Beach Club", "🏖️ Little Vagator Beach", "💎 Ozran Cliff Path")
                ),
                DestinationSpot(
                    name = "Fontainhas Latin Quarter Walking Tour",
                    category = "🏛️ Heritage & Architecture",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Panjim (Central Goa)",
                    durationMinutes = 120,
                    estimatedCostUSD = 5.0,
                    description = "Charming heritage quarter with pastel-colored Portuguese villas, ornate wooden balconies, and boutique art cafes.",
                    tags = listOf("Culture", "History", "Photography", "Romantic", "Cafés"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("☕ Café Bodega Courtyard", "🍷 Viva Panjim Traditional Goan Dining", "🛍️ 31st January Road Boutiques", "🏛️ Immaculate Conception Church")
                ),
                DestinationSpot(
                    name = "Anjuna Flea Market & Curlies Sunset",
                    category = "🛍️ Markets & Nightlife",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "North Goa (Anjuna)",
                    durationMinutes = 150,
                    estimatedCostUSD = 20.0,
                    description = "Eclectic seaside artisan market followed by hypnotic sundowner sets over the rocky Anjuna coastline.",
                    tags = listOf("Shopping", "Nightlife", "Food", "Beach", "Mixed"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("🎉 Curlies & Shiva Valley Beach Club", "☕ German Bakery Anjuna", "🏖️ South Anjuna Rocky Cove", "🍜 Burger Factory")
                ),
                DestinationSpot(
                    name = "Dudhsagar Waterfalls & Jungle Jeep Trek",
                    category = "🌿 Nature & Adventure",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "South Goa / Western Ghats",
                    durationMinutes = 240,
                    estimatedCostUSD = 30.0,
                    description = "Spectacular four-tiered waterfall cascading down sheer rock through the lush tropical forest.",
                    tags = listOf("Adventure", "Nature", "Activities", "Photography", "Family"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🌿 Tropical Spice Plantation Lunch", "🐒 Bhagwan Mahaveer Wildlife Sanctuary", "💎 Tambdi Surla Ancient Temple")
                ),
                DestinationSpot(
                    name = "Palolem Beach & Butterfly Island Kayaking",
                    category = "🏖️ Serene Beach",
                    priorityBadge = "💎 HIDDEN GEM",
                    zone = "South Goa (Canacona)",
                    durationMinutes = 180,
                    estimatedCostUSD = 18.0,
                    description = "Crescent bay fringed with swaying coconut palms, calm turquoise waters ideal for sea kayaking and dolphin watching.",
                    tags = listOf("Beach", "Relaxed", "Romantic", "Wellness", "Nature"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("☕ Dropadi Waterfront Dining", "🛶 Secret Butterfly Beach Boat Tour", "🧘 Yoga Shala Palolem", "🌅 Rajbaga Beach Sunset")
                ),
                DestinationSpot(
                    name = "Fort Aguada & Ancient Lighthouse",
                    category = "🏛️ Historical Monument",
                    priorityBadge = "👍 WORTH VISITING",
                    zone = "North Goa (Candolim)",
                    durationMinutes = 90,
                    estimatedCostUSD = 3.0,
                    description = "Well-preserved Portuguese fortress overlooking Sinquerim beach with an imposing four-story lighthouse.",
                    tags = listOf("History", "Sightseeing", "Photography", "Family"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🏖️ Sinquerim Beach", "☕ Cohiba Bar & Kitchen", "🍴 Fisherman's Cove Candolim", "🛍️ Candolim Strip")
                ),
                DestinationSpot(
                    name = "Night Market at Arpora & Live Music",
                    category = "🎉 Nightlife & Food",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "North Goa (Arpora)",
                    durationMinutes = 180,
                    estimatedCostUSD = 25.0,
                    description = "Open-air festival market with hundreds of global culinary stalls, live bands, and artisan designers.",
                    tags = listOf("Nightlife", "Food", "Shopping", "Mixed"),
                    bestTimeOfDay = "Night",
                    nearbySuggestions = listOf("🎉 Club Cabana hilltop dancefloor", "🍜 Global Food Stalls", "🍸 Boutique Gin Bar")
                )
            )
        ),
        DestinationData(
            id = "tokyo",
            name = "Tokyo",
            country = "Japan",
            region = "East Asia",
            localCurrency = CurrencyInfo("JPY", "Japanese Yen", "¥", 152.0),
            typicalDailyCostUSD = 110.0,
            isInternationalForINR = true,
            bestSeasons = "Mar - May (Cherry Blossoms) & Oct - Nov (Autumn Foliage)",
            highlights = listOf("Historic temples & ultramodern neon", "Michelin ramen & street food", "Akihabara tech culture", "Shibuya Scramble"),
            spots = listOf(
                DestinationSpot(
                    name = "Senso-ji Temple & Nakamise-dori",
                    category = "🏛️ Historic & Cultural",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Asakusa",
                    durationMinutes = 120,
                    estimatedCostUSD = 5.0,
                    description = "Tokyo's oldest and most significant Buddhist temple featuring the iconic Kaminarimon thunder gate and historic market street.",
                    tags = listOf("History", "Culture", "Sightseeing", "Photography", "Food"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🍜 Asakusa Imahan Sukiyaki", "☕ Suzukien Matcha Gelato (7 Richness Levels)", "🗼 Tokyo Skytree Observation Deck", "🚢 Sumida River Cruise")
                ),
                DestinationSpot(
                    name = "Shibuya Crossing & Hachiko Statue",
                    category = "📸 Famous Landmark",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Shibuya",
                    durationMinutes = 90,
                    estimatedCostUSD = 10.0,
                    description = "The world's busiest pedestrian intersection with dazzling video screens and the legendary loyal dog Hachiko bronze monument.",
                    tags = listOf("Sightseeing", "Photography", "Mixed", "Shopping"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("☕ Shibuya Sky 360 Open-air Deck", "🍜 Ichiran Shibuya Ramen", "🛍️ Shibuya 109 & Miyashita Park", "🎉 Nonbei Yokocho alley bars")
                ),
                DestinationSpot(
                    name = "Meiji Jingu Shrine & Yoyogi Forest",
                    category = "🌿 Nature & Spiritual",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Harajuku",
                    durationMinutes = 90,
                    estimatedCostUSD = 0.0,
                    description = "Tranquil Imperial Shinto shrine enveloped in a dense 170-acre sacred evergreen forest of 100,000 trees.",
                    tags = listOf("Culture", "Nature", "Wellness", "Photography", "Relaxed"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🛍️ Takeshita Street Kawaii Boutiques", "☕ Cat Street specialty coffee roasters", "🍜 Afuri Yuzu Ramen", "🛍️ Omotesando Luxury Boulevard")
                ),
                DestinationSpot(
                    name = "Shinjuku Omoide Yokocho & Neon Kabukicho",
                    category = "🎉 Nightlife & Izakaya",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "Shinjuku",
                    durationMinutes = 150,
                    estimatedCostUSD = 35.0,
                    description = "Atmospheric post-war lantern-lit lantern alleyways grilling smoking yakitori skewers beneath towering cyber neon lights.",
                    tags = listOf("Nightlife", "Food", "Culture", "Photography"),
                    bestTimeOfDay = "Night",
                    nearbySuggestions = listOf("🍸 Golden Gai Micro Bars", "🏙️ Tokyo Metropolitan Gov Building Observatory", "🍜 Fuunji Tsukemen Noodle House", "🦖 Godzilla Road Walk")
                ),
                DestinationSpot(
                    name = "teamLab Planets Immersive Digital Art",
                    category = "🎨 Modern Art & Activities",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Toyosu / Odaiba",
                    durationMinutes = 120,
                    estimatedCostUSD = 32.0,
                    description = "World-famous body-immersive museum where you walk through water and sensory digital floral infinity gardens.",
                    tags = listOf("Activities", "Photography", "Romantic", "Family"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("🍣 Toyosu Fish Market Fresh Sushi Dai", "🌅 Odaiba Seaside Park Sunset", "🛍️ DiverCity Tokyo Giant Gundam", "☕ Bills Odaiba waterfront café")
                ),
                DestinationSpot(
                    name = "Akihabara Electric Town & Retro Gaming",
                    category = "🛍️ Anime, Tech & Gaming",
                    priorityBadge = "👍 WORTH VISITING",
                    zone = "Akihabara",
                    durationMinutes = 120,
                    estimatedCostUSD = 20.0,
                    description = "The vibrant epicentre of global otaku culture, multi-level manga stores, arcade centers, and vintage electronics.",
                    tags = listOf("Shopping", "Activities", "Mixed"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("☕ Maid & Themed Character Cafes", "🎮 Super Potato Vintage Game Emporium", "🍜 Kanda Matsuya Soba Heritage", "🛍️ Radio Kaikan 10 Floors")
                ),
                DestinationSpot(
                    name = "Roppongi Hills Mori Tower & Tokyo Tower Sunset",
                    category = "🌅 Sunset & Viewpoint",
                    priorityBadge = "📸 PHOTO SPOT",
                    zone = "Roppongi / Minato",
                    durationMinutes = 90,
                    estimatedCostUSD = 18.0,
                    description = "Stunning rooftop observatory showcasing iconic Tokyo Tower glowing amber against Mt. Fuji silhouette at sunset.",
                    tags = listOf("Sunset spot", "Romantic", "Photography", "Sightseeing"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("🗼 Tokyo Tower Base Walk", "🎨 Mori Art Museum Contemporary", "🍸 The Oak Door Lounge", "🍴 Roppongi Hills Fine Dining")
                ),
                DestinationSpot(
                    name = "Yanaka Ginza Nostalgic Old Town",
                    category = "💎 Hidden Gem & Heritage",
                    priorityBadge = "💎 HIDDEN GEM",
                    zone = "Yanaka / Ueno",
                    durationMinutes = 100,
                    estimatedCostUSD = 12.0,
                    description = "One of the few surviving historic neighborhoods displaying traditional Edo retro charm, cat bakeries, and woodcrafts.",
                    tags = listOf("Hidden gems", "Culture", "Relaxed", "Cafés", "Food"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("☕ Kayaba Coffee (Historic 1938 Kissaten)", "🌿 Ueno Park & Shinobazu Pond", "🥟 Local Menchi-katsu street croquettes", "🏛️ Tokyo National Museum")
                )
            )
        ),
        DestinationData(
            id = "paris",
            name = "Paris",
            country = "France",
            region = "Western Europe",
            localCurrency = CurrencyInfo("EUR", "Euro", "€", 0.92),
            typicalDailyCostUSD = 135.0,
            isInternationalForINR = true,
            bestSeasons = "Apr - Jun & Sep - Nov (Mild sunny weather & cafe terraces)",
            highlights = listOf("Eiffel Tower & Seine sunset cruises", "Louvre & Musée d'Orsay", "Montmartre bohemian cafes", "Champs-Élysées"),
            spots = listOf(
                DestinationSpot(
                    name = "Eiffel Tower & Champ de Mars",
                    category = "🏛️ Famous Landmark",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "7th Arrondissement",
                    durationMinutes = 120,
                    estimatedCostUSD = 28.0,
                    description = "The world's most romantic architectural icon, offering breathtaking panoramic summit views and sparkling hourly night lights.",
                    tags = listOf("Sightseeing", "Romantic", "Photography", "Family"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("🚢 Vedettes de Paris Seine River Cruise", "☕ Café de l'Homme Trocadéro View", "📸 Trocadéro Gardens Photo Steps", "🍴 Le Bistro Parisien Waterfront")
                ),
                DestinationSpot(
                    name = "Louvre Museum & Glass Pyramid",
                    category = "🎨 Art & History",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "1st Arrondissement",
                    durationMinutes = 180,
                    estimatedCostUSD = 22.0,
                    description = "The world's largest art museum housing timeless masterpieces including the Mona Lisa, Venus de Milo, and Winged Victory.",
                    tags = listOf("History", "Culture", "Sightseeing", "Photography"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🌿 Tuileries Gardens Walk", "☕ Angelina Paris Famous Hot Chocolate", "🏛️ Palais Royal Columns & Courtyard", "🛍️ Rue de Rivoli boutiques")
                ),
                DestinationSpot(
                    name = "Montmartre & Sacré-Cœur Basilica",
                    category = "🌅 Heritage & Bohemian Quarter",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "18th Arrondissement",
                    durationMinutes = 150,
                    estimatedCostUSD = 5.0,
                    description = "Hilltop white stone basilica with commanding sunset vistas over all Paris, cobblestone streets, and artist portrait squares.",
                    tags = listOf("Culture", "Romantic", "Photography", "Sunset spot", "Cafés"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("☕ Le Consulat Famous Bohemian Bistro", "🎨 Place du Tertre Open-air Painters", "💎 Clos Montmartre Secret Vineyard", "🎉 Moulin Rouge Cabaret")
                ),
                DestinationSpot(
                    name = "Notre-Dame Cathedral & Île de la Cité",
                    category = "🏛️ Historic & Island",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "4th Arrondissement",
                    durationMinutes = 90,
                    estimatedCostUSD = 0.0,
                    description = "Gothic masterpiece standing proudly in the heart of the Seine river, surrounded by medieval quays and flower markets.",
                    tags = listOf("History", "Culture", "Sightseeing", "Photography"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("📚 Shakespeare and Company English Bookshop", "🍦 Berthillon Artisanal Glaces on Île Saint-Louis", "🏛️ Sainte-Chapelle Stained Glass Marvel", "☕ Le Saint-Régis classic corner café")
                ),
                DestinationSpot(
                    name = "Arc de Triomphe & Champs-Élysées Walk",
                    category = "🏛️ Monument & Shopping",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "8th Arrondissement",
                    durationMinutes = 90,
                    estimatedCostUSD = 16.0,
                    description = "Imposing triumphal monument honoring French history with rooftop views down 12 radiating grand boulevards.",
                    tags = listOf("Sightseeing", "Shopping", "Photography", "History"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("🛍️ Ladurée Champs-Élysées Macaron Salon", "🛍️ Galeries Lafayette Champs-Élysées", "☕ Fouquet's Historic Brasserie", "🏛️ Grand Palais Exhibition Hall")
                ),
                DestinationSpot(
                    name = "Musée d'Orsay Impressionist Masterpieces",
                    category = "🎨 Art Museum",
                    priorityBadge = "👍 WORTH VISITING",
                    zone = "7th Arrondissement",
                    durationMinutes = 120,
                    estimatedCostUSD = 18.0,
                    description = "Magnificent Beaux-Arts railway station transformed into a premier collection of Monet, Van Gogh, Renoir, and Degas works.",
                    tags = listOf("Culture", "History", "Photography", "Relaxed"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("📸 Famous Giant Clock Face Photo Spot", "☕ Café Campana", "🚶 Left Bank Seine Promenade", "🍷 Saint-Germain-des-Prés wine cellars")
                ),
                DestinationSpot(
                    name = "Le Marais Historic Quarter & Place des Vosges",
                    category = "💎 Trendy Heritage & Food",
                    priorityBadge = "💎 HIDDEN GEM",
                    zone = "3rd / 4th Arrondissement",
                    durationMinutes = 120,
                    estimatedCostUSD = 15.0,
                    description = "Aristocratic square with 17th-century brick arcades, indie fashion boutiques, trendy patisseries, and world-class falafel.",
                    tags = listOf("Food", "Shopping", "Cafés", "Romantic", "Hidden gems"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("🥙 L'As du Fallafel World-Famous Street Food", "☕ Carette Tea Room with Salted Caramel Éclair", "🏛️ Picasso Museum Hotel Salé", "🎨 Hidden Private Courtyards")
                ),
                DestinationSpot(
                    name = "Latin Quarter Jazz & Saint-Germain Evening",
                    category = "🎉 Nightlife & Music",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "5th / 6th Arrondissement",
                    durationMinutes = 150,
                    estimatedCostUSD = 30.0,
                    description = "Historic literary haven bursting with underground jazz cellars, candlelit wine bars, and student taverns.",
                    tags = listOf("Nightlife", "Culture", "Food", "Romantic"),
                    bestTimeOfDay = "Night",
                    nearbySuggestions = listOf("🎷 Caveau de la Huchette 1946 Jazz Cellar", "☕ Café de Flore Philosophical Terrace", "🍷 Le Comptoir du Relais Bistro", "🏛️ Panthéon Monument by Night")
                )
            )
        ),
        DestinationData(
            id = "dubai",
            name = "Dubai",
            country = "United Arab Emirates",
            region = "Middle East",
            localCurrency = CurrencyInfo("AED", "UAE Dirham", "د.إ", 3.67),
            typicalDailyCostUSD = 150.0,
            isInternationalForINR = true,
            bestSeasons = "Nov - Mar (Pleasant desert weather, outdoor festivals)",
            highlights = listOf("Burj Khalifa & Dubai Fountain", "Desert Safari with dune bashing", "Palm Jumeirah luxury", "Historic Gold & Spice Souks"),
            spots = listOf(
                DestinationSpot(
                    name = "Burj Khalifa At The Top & Dubai Fountain",
                    category = "🏛️ Iconic Skyscraper",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Downtown Dubai",
                    durationMinutes = 120,
                    estimatedCostUSD = 45.0,
                    description = "The world's tallest building (828m) offering awe-inspiring observation decks and choreographed fountain lake shows.",
                    tags = listOf("Sightseeing", "Photography", "Family", "Romantic"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("🛍️ Dubai Mall Aquarium & Underwater Zoo", "☕ Armani / Lounge Burj views", "🍴 Time Out Market Dubai culinary hub", "📸 Wings of Mexico Photo Sculpture")
                ),
                DestinationSpot(
                    name = "Desert Safari & Bedouin Sunset Camp",
                    category = "🏔️ Adventure & Culture",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Lahbab Desert Red Dunes",
                    durationMinutes = 300,
                    estimatedCostUSD = 55.0,
                    description = "Exciting 4x4 dune bashing, camel riding, sandboarding, falconry photos, and open-air BBQ dinner under desert stars.",
                    tags = listOf("Adventure", "Culture", "Activities", "Sunset spot", "Family", "Mixed"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("🐪 Camel Caravan Trekking", "✨ Stargazing in the dunes", "💃 Tanoura & Fire dance shows", "🍵 Traditional Arabic Gahwa coffee")
                ),
                DestinationSpot(
                    name = "Museum of the Future",
                    category = "🎨 Future Tech & Architecture",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Sheikh Zayed Road",
                    durationMinutes = 120,
                    estimatedCostUSD = 40.0,
                    description = "Architectural masterpiece inscribed with Arabic calligraphy, exhibiting sensory voyages to 2071 space and biodiversity ecosystems.",
                    tags = listOf("Activities", "Sightseeing", "Photography", "Family"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("📸 Calligraphy Ring Exterior Photo Terrace", "☕ Robotic Barista Café", "🏛️ Emirates Towers Boulevard", "🚇 Dubai Metro Future Station")
                ),
                DestinationSpot(
                    name = "Al Fahidi Heritage District & Gold Souk Abra Ride",
                    category = "🏛️ Traditional Culture & Souks",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "Old Dubai (Deira & Bur Dubai)",
                    durationMinutes = 150,
                    estimatedCostUSD = 8.0,
                    description = "Wind-tower gypsum coral houses, traditional 1-Dirham wooden Abra boat crossing on Dubai Creek, and glittering Gold and Spice souks.",
                    tags = listOf("Culture", "History", "Shopping", "Food", "Photography"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("☕ Arabian Tea House Special Platter", "🛥️ Historic Abra Boat Creek Crossing", "🛍️ Deira Spice & Saffron Bazaar", "🏛️ Dubai Coffee Museum")
                ),
                DestinationSpot(
                    name = "Palm Jumeirah & The View at The Palm",
                    category = "📸 Panoramic Island View",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "Palm Jumeirah",
                    durationMinutes = 90,
                    estimatedCostUSD = 30.0,
                    description = "52nd-floor glass terrace showcasing 360-degree views of the man-made palm archipelago, Arabian Gulf, and Marina skyscrapers.",
                    tags = listOf("Sightseeing", "Photography", "Romantic"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("🏖️ Atlantis The Royal & Aquaventure Waterpark", "☕ The Pointe Boardwalk", "🍹 Club Vista Mare Beach Lounges", "🛥️ Yacht Cruise Marina Tour")
                ),
                DestinationSpot(
                    name = "Dubai Marina Promenade & JBR Beach Walk",
                    category = "🏖️ Beach & Nightlife",
                    priorityBadge = "👍 WORTH VISITING",
                    zone = "Dubai Marina / JBR",
                    durationMinutes = 150,
                    estimatedCostUSD = 25.0,
                    description = "Vibrant cosmopolitan waterfront framed by illuminated towers, seaside open-air dining, beach day clubs, and street performers.",
                    tags = listOf("Beach", "Nightlife", "Food", "Relaxed", "Shopping"),
                    bestTimeOfDay = "Night",
                    nearbySuggestions = listOf("☕ Pier 7 Multi-tier Panoramic Dining", "🏖️ Ain Dubai Ferris Wheel Walk", "🍹 Barasti Beach Club", "🛍️ The Beach outdoor mall")
                ),
                DestinationSpot(
                    name = "Miracle Garden & Floral Castles",
                    category = "🌿 Nature & Family",
                    priorityBadge = "👍 WORTH VISITING",
                    zone = "Al Barsha South",
                    durationMinutes = 120,
                    estimatedCostUSD = 25.0,
                    description = "World's largest natural flower garden featuring over 150 million blooming flowers arranged in Airbus A380 and fairytale castles.",
                    tags = listOf("Nature", "Family", "Photography", "Romantic"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🦋 Dubai Butterfly Garden (15,000 butterflies)", "☕ Floral Umbrella Café", "📸 Heart-shaped Blossom Tunnel")
                ),
                DestinationSpot(
                    name = "Al Qudra Love Lakes & Wildlife Desert Dunes",
                    category = "💎 Hidden Gem & Sunset",
                    priorityBadge = "💎 HIDDEN GEM",
                    zone = "Al Qudra Oasis",
                    durationMinutes = 120,
                    estimatedCostUSD = 5.0,
                    description = "Secluded interconnected heart-shaped desert lakes surrounded by desert trees, gazelles, black swans, and peaceful sunset picnics.",
                    tags = listOf("Hidden gems", "Nature", "Romantic", "Sunset spot", "Wellness"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("🚲 Al Qudra Cycling Desert Track", "🦆 Desert Birdwatching Flamingo Watch", "🔥 Campfire Picnic Spots")
                )
            )
        ),
        DestinationData(
            id = "bali",
            name = "Bali",
            country = "Indonesia",
            region = "Southeast Asia",
            localCurrency = CurrencyInfo("IDR", "Indonesian Rupiah", "Rp", 15800.0),
            typicalDailyCostUSD = 55.0,
            isInternationalForINR = true,
            bestSeasons = "Apr - Oct (Dry sunny season, gentle coastal surf)",
            highlights = listOf("Ubud lush jungle & rice terraces", "Uluwatu cliff temples & Kecak sunset", "Canggu surf & healthy cafes", "Nusa Penida islands"),
            spots = listOf(
                DestinationSpot(
                    name = "Tegallalang Rice Terraces & Jungle Swing",
                    category = "🌿 Nature & Adventure",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Ubud",
                    durationMinutes = 120,
                    estimatedCostUSD = 12.0,
                    description = "Stepped emerald green valley with ancient Subak irrigation system, giant bamboo swings soaring over the jungle canopy.",
                    tags = listOf("Nature", "Photography", "Adventure", "Romantic"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("☕ Cretya Ubud Day Club & Infinity Pool", "☕ Luwak Coffee Plantation Tasting", "🐒 Sacred Monkey Forest Sanctuary", "🛍️ Ubud Art Market Handcrafts")
                ),
                DestinationSpot(
                    name = "Uluwatu Cliff Temple & Fire Kecak Dance",
                    category = "🌅 Sunset & Culture",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Uluwatu Peninsula",
                    durationMinutes = 150,
                    estimatedCostUSD = 15.0,
                    description = "Perched dramatically on a 70m limestone sea cliff, hosting hypnotic rhythmic Kecak chorus as the red sun sets into the Indian Ocean.",
                    tags = listOf("Sunset spot", "Culture", "History", "Photography", "Romantic"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("🍹 Single Fin Clifftop Surf Bar", "🏖️ Padang Padang Secret Beach", "🍴 Jimbaran Bay Candlelit Seafood on Sand", "🏖️ Thomas Beach Cove")
                ),
                DestinationSpot(
                    name = "Sacred Monkey Forest Sanctuary",
                    category = "🌿 Wildlife & Heritage",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "Ubud Central",
                    durationMinutes = 90,
                    estimatedCostUSD = 6.0,
                    description = "Mystical moss-covered Hindu temple complex shaded by towering banyan trees, home to over 1,000 playful Balinese macaques.",
                    tags = listOf("Nature", "Culture", "Family", "Photography"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("☕ Milk & Madu Ubud café", "🏛️ Ubud Royal Palace (Puri Saren Agung)", "🍜 Warung Babi Guling Ibu Oka", "🧘 The Yoga Barn Class")
                ),
                DestinationSpot(
                    name = "Canggu Beach & Echo Beach Sundowners",
                    category = "🏖️ Beach, Cafés & Nightlife",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "Canggu / Berawa",
                    durationMinutes = 180,
                    estimatedCostUSD = 25.0,
                    description = "World-famous surf hub lined with bohemian boutique cafes, beachfront beanbags, acoustic reggae, and lively beach clubs.",
                    tags = listOf("Beach", "Cafés", "Nightlife", "Food", "Relaxed"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("🍹 La Brisa Vintage Pirate Ship Beach Club", "☕ Crate Cafe Big Brekkie", "🎉 Old Man's Beach Bar", "🛍️ Love Anchor Canggu Boutique Market")
                ),
                DestinationSpot(
                    name = "Ulun Danu Beratan Water Temple",
                    category = "🏛️ Scenic Lake Temple",
                    priorityBadge = "📸 PHOTO SPOT",
                    zone = "Bedugul Highlands",
                    durationMinutes = 90,
                    estimatedCostUSD = 5.0,
                    description = "Floating 17th-century Hindu water shrine surrounded by calm mountain mist and glassy waters of Lake Beratan.",
                    tags = listOf("Sightseeing", "Photography", "Culture", "Nature"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🌿 Bali Botanic Garden & Treetop Walk", "☕ Handara Iconic Golf Gate Photo Spot", "🍓 Fresh Highland Strawberry Farms")
                ),
                DestinationSpot(
                    name = "Nusa Penida Kelingking 'T-Rex' Cliff & Broken Beach",
                    category = "🏔️ Day Island Adventure",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Nusa Penida Island",
                    durationMinutes = 360,
                    estimatedCostUSD = 45.0,
                    description = "Breathtaking T-Rex shaped limestone cliff plunging into turquoise waves, manta ray snorkeling, and natural rock archways.",
                    tags = listOf("Adventure", "Photography", "Beach", "Nature"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🏖️ Crystal Bay Snorkeling with Manta Rays", "🌊 Angel's Billabong Natural Tidal Pool", "📸 Diamond Beach Thousand Islands Viewpoint")
                ),
                DestinationSpot(
                    name = "Tirta Empul Holy Water Spring Temple",
                    category = "🛕 Spiritual Cleansing",
                    priorityBadge = "👍 WORTH VISITING",
                    zone = "Tampaksiring (Near Ubud)",
                    durationMinutes = 90,
                    estimatedCostUSD = 4.0,
                    description = "Sacred 10th-century natural crystal mountain spring pools where travelers participate in the traditional Melukat purification ritual.",
                    tags = listOf("Culture", "Wellness", "History", "Relaxed"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🏛️ Gunung Kawi Ancient Cliff Royal Tombs", "🌿 Kintamani Mount Batur Volcano View Café")
                ),
                DestinationSpot(
                    name = "Sidemen Valley Bamboo Forest & River Walk",
                    category = "💎 Hidden Gem & Serenity",
                    priorityBadge = "💎 HIDDEN GEM",
                    zone = "East Bali (Sidemen)",
                    durationMinutes = 120,
                    estimatedCostUSD = 10.0,
                    description = "Unspoiled rural Bali valley with traditional weavers, wild river stone paths, Mount Agung views, and zero crowds.",
                    tags = listOf("Hidden gems", "Nature", "Wellness", "Romantic", "Relaxed"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("☕ Asri Dining Eco-Resort", "🧵 Traditional Endek & Songket Hand-weaving studios", "🌊 Telaga Waja River Rafting")
                )
            )
        ),
        DestinationData(
            id = "bangkok",
            name = "Bangkok",
            country = "Thailand",
            region = "Southeast Asia",
            localCurrency = CurrencyInfo("THB", "Thai Baht", "฿", 35.5),
            typicalDailyCostUSD = 50.0,
            isInternationalForINR = true,
            bestSeasons = "Nov - Feb (Cool dry breeze)",
            highlights = listOf("Grand Palace & Emerald Buddha", "Wat Arun Riverside Sunset", "Michelin Street food & night markets", "Chao Phraya River"),
            spots = listOf(
                DestinationSpot(
                    name = "Grand Palace & Wat Phra Kaew (Emerald Buddha)",
                    category = "🏛️ Royal Heritage",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Rattanakosin Old City",
                    durationMinutes = 150,
                    estimatedCostUSD = 15.0,
                    description = "Dazzling 1782 royal residence with golden spires, intricate mosaic tiles, and the venerated Emerald Buddha.",
                    tags = listOf("History", "Culture", "Sightseeing", "Photography"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🛕 Wat Pho (Giant Reclining Buddha & Thai Massage)", "🍜 Thip Samai Pad Thai Pratu Phi", "☕ Blue Whale Butterfly Pea Café", "🚢 Tha Tien Pier Boat Crossings")
                ),
                DestinationSpot(
                    name = "Wat Arun (Temple of Dawn) & Riverside Sunset",
                    category = "🌅 Sunset & Landmark",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Chao Phraya River Bank (Thonburi)",
                    durationMinutes = 90,
                    estimatedCostUSD = 3.0,
                    description = "Magnificent porcelain-encrusted pagoda tower towering over the river, catching magical fiery sunset reflections.",
                    tags = listOf("Sunset spot", "Culture", "Photography", "Romantic"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("☕ Riva Arun Rooftop Deck", "🚢 Chao Phraya Express River Ferry", "📸 Traditional Thai Silk Dress Rental", "🍸 The Deck by Arun Residence")
                ),
                DestinationSpot(
                    name = "Chatuchak Weekend Market & Street Food",
                    category = "🛍️ World's Largest Market",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "Mo Chit",
                    durationMinutes = 180,
                    estimatedCostUSD = 20.0,
                    description = "Over 15,000 stalls offering vintage fashion, local crafts, tropical fruit smoothies, coconut ice cream, and street delicacies.",
                    tags = listOf("Shopping", "Food", "Mixed"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🥥 Coco JJ Signature Coconut Ice Cream", "🍜 Guay Tiew Kua Gai Crispy Noodles", "🌿 Chatuchak Park Garden Rest")
                ),
                DestinationSpot(
                    name = "Jodd Fairs Night Market & Volcano Ribs",
                    category = "🎉 Nightlife & Food Market",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "Rama 9",
                    durationMinutes = 120,
                    estimatedCostUSD = 18.0,
                    description = "Trendy open-air street feast with spicy mountain ribs, crispy butter rotis, craft cocktails, and live acoustic music.",
                    tags = listOf("Nightlife", "Food", "Shopping"),
                    bestTimeOfDay = "Night",
                    nearbySuggestions = listOf("🍖 Leng Saap Giant Spicy Pork Ribs", "🍧 Strawberry Kakigori Shaved Ice", "🍻 Rooftop Craft Beer Bars")
                ),
                DestinationSpot(
                    name = "Chinatown (Yaowarat) Street Food Safari",
                    category = "🍜 Culinary Heritage",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Yaowarat",
                    durationMinutes = 120,
                    estimatedCostUSD = 15.0,
                    description = "World capital of street gastronomy; glowing neon dragons, sizzling woks, crab omelettes, and toasted sweet buns.",
                    tags = listOf("Food", "Culture", "Nightlife", "Photography"),
                    bestTimeOfDay = "Night",
                    nearbySuggestions = listOf("🦀 Jay Fai Michelin Bib Gourmand Crab Omelette", "🍞 Yaowarat Toasted Buns with Pandan Custard", "🍸 Tep Bar Thai Herbal Cocktails", "🛕 Wat Traimit Golden Buddha (5.5 tons solid gold)")
                ),
                DestinationSpot(
                    name = "ICONSIAM & SookSiam Indoor Floating Market",
                    category = "🛍️ Luxury Mall & Cultural Experience",
                    priorityBadge = "👍 WORTH VISITING",
                    zone = "Riverside",
                    durationMinutes = 120,
                    estimatedCostUSD = 15.0,
                    description = "Riverside megamall featuring an indoor floating market showcasing 77 Thai provinces food, art, and light water shows.",
                    tags = listOf("Shopping", "Food", "Family", "Activities"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("🚢 Free ICONSIAM Shuttle Boat", "☕ Starbucks Reserve Rooftop River Terrace", "🎭 Thai Traditional Puppet Shows")
                )
            )
        ),
        DestinationData(
            id = "newyork",
            name = "New York City",
            country = "United States",
            region = "North America",
            localCurrency = CurrencyInfo("USD", "US Dollar", "$", 1.0),
            typicalDailyCostUSD = 175.0,
            isInternationalForINR = true,
            bestSeasons = "May - Jun & Sep - Nov (Crisp autumn park leaves)",
            highlights = listOf("Central Park & Times Square", "Statue of Liberty & Brooklyn Bridge", "Broadway shows", "Empire State & Summit One"),
            spots = listOf(
                DestinationSpot(
                    name = "Central Park & Bethesda Terrace",
                    category = "🌿 Urban Nature & History",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Manhattan (Midtown - Uptown)",
                    durationMinutes = 150,
                    estimatedCostUSD = 0.0,
                    description = "843 acres of sprawling green sanctuary, rowboats on the lake, Bow Bridge, and historic arcade architecture.",
                    tags = listOf("Nature", "Photography", "Romantic", "Family", "Relaxed"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🏛️ Metropolitan Museum of Art (The Met)", "☕ The Boathouse Lake Restaurant", "🚣 Rowboat Rental on Central Park Lake", "🥯 Absolute Bagels")
                ),
                DestinationSpot(
                    name = "Summit One Vanderbilt & Midtown Skyline",
                    category = "📸 Modern Mirror Observatory",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Midtown Manhattan",
                    durationMinutes = 90,
                    estimatedCostUSD = 45.0,
                    description = "Multi-sensory infinity mirror installation giving the illusion of walking in the sky above the Empire State and Chrysler buildings.",
                    tags = listOf("Activities", "Photography", "Sightseeing", "Family"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("🏛️ Grand Central Terminal Whispering Gallery", "🍕 Joe's Pizza Broadway slice", "📚 New York Public Library Rose Reading Room", "🌿 Bryant Park Lawn")
                ),
                DestinationSpot(
                    name = "Brooklyn Bridge Walk & DUMBO Waterfront",
                    category = "🌅 Sunset & Landmark Walk",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Lower Manhattan / Brooklyn",
                    durationMinutes = 120,
                    estimatedCostUSD = 0.0,
                    description = "Gothic stone arches over the East River followed by iconic Manhattan bridge street photos in cobblestone DUMBO.",
                    tags = listOf("Sightseeing", "Photography", "Sunset spot", "Romantic"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("🍕 Grimaldi's or Juliana's Coal Fired Pizza", "🍦 Brooklyn Ice Cream Factory", "📸 Washington Street DUMBO Photo Alley", "🎠 Jane's Carousel Waterfront")
                ),
                DestinationSpot(
                    name = "Times Square & Broadway Theater District",
                    category = "🎉 Nightlife & Entertainment",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "Theater District",
                    durationMinutes = 150,
                    estimatedCostUSD = 85.0,
                    description = "The Crossroads of the World pulsating with massive LED billboards, street energy, and world-class Broadway musicals.",
                    tags = listOf("Nightlife", "Activities", "Sightseeing", "Family"),
                    bestTimeOfDay = "Night",
                    nearbySuggestions = listOf("🎭 Lion King / Hamilton / Wicked Musicals", "🍔 Shake Shack Original Midtown", "🛍️ M&M's and Disney Flagships", "🍸 St. Cloud Rooftop Bar")
                ),
                DestinationSpot(
                    name = "The High Line & Chelsea Market Feast",
                    category = "🌿 Urban Trail & Gourmet Food",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "Meatpacking & Chelsea",
                    durationMinutes = 120,
                    estimatedCostUSD = 25.0,
                    description = "Elevated 1.45-mile greenway built on a historic freight rail line winding between art murals, Hudson River views, and food halls.",
                    tags = listOf("Food", "Nature", "Culture", "Photography"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("🦞 Chelsea Market Fresh Lobster Place", "🏛️ Whitney Museum of American Art", "🏗️ The Vessel at Hudson Yards", "☕ Blue Bottle Coffee High Line")
                ),
                DestinationSpot(
                    name = "Greenwich Village & SoHo Historic Cast-Iron District",
                    category = "💎 Bohemian Heritage & Shopping",
                    priorityBadge = "💎 HIDDEN GEM",
                    zone = "Lower Manhattan",
                    durationMinutes = 150,
                    estimatedCostUSD = 20.0,
                    description = "Tree-lined Brownstones, historic speakeasies, comedy cellars, designer boutiques, and espresso cafes.",
                    tags = listOf("Hidden gems", "Shopping", "Cafés", "Romantic", "Food"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("🎭 Comedy Cellar MacDougal St", "☕ Caffe Dante World's Best Aperitivo", "🍕 Bleeker Street Pizza", "🛍️ SoHo Designer Flagships")
                )
            )
        ),
        DestinationData(
            id = "london",
            name = "London",
            country = "United Kingdom",
            region = "Western Europe",
            localCurrency = CurrencyInfo("GBP", "British Pound", "£", 0.78),
            typicalDailyCostUSD = 140.0,
            isInternationalForINR = true,
            bestSeasons = "May - Sep (Long sunny daylight hours & green royal parks)",
            highlights = listOf("Big Ben & Westminster", "Tower Bridge & Tower of London", "Borough Market food feast", "British Museum & West End"),
            spots = listOf(
                DestinationSpot(
                    name = "Big Ben & Westminster Abbey",
                    category = "🏛️ Historic & Royal",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Westminster",
                    durationMinutes = 120,
                    estimatedCostUSD = 28.0,
                    description = "The world's most famous clock tower overlooking the Houses of Parliament and the coronation church of British monarchs.",
                    tags = listOf("History", "Culture", "Sightseeing", "Photography"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🎡 London Eye 30-min River Capsule", "🌿 St. James's Park Pelican Walk", "🏛️ Buckingham Palace Changing of the Guard", "☕ Westminster River Cafe")
                ),
                DestinationSpot(
                    name = "Tower Bridge & Historic Tower of London",
                    category = "🏛️ Fortress & Victorian Bridge",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "City / Southwark",
                    durationMinutes = 150,
                    estimatedCostUSD = 35.0,
                    description = "Iconic suspension bridge with glass floor walkways and nearly 1,000-year-old medieval fortress guarding the Crown Jewels.",
                    tags = listOf("History", "Sightseeing", "Photography", "Family"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🍴 Coppa Club Glass Igloos by the River", "🚢 Thames Clipper River Ferry to Greenwich", "📸 Girl with a Dolphin Fountain photo")
                ),
                DestinationSpot(
                    name = "Borough Market Gourmet Food Hall",
                    category = "🍜 Historic Food Market",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "London Bridge",
                    durationMinutes = 90,
                    estimatedCostUSD = 18.0,
                    description = "London's oldest food market (since 1756) packed with sizzling paellas, artisan cheeses, Scottish scotch eggs, and doughnut bakeries.",
                    tags = listOf("Food", "Culture", "Mixed"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("🥪 Kappacasein Swiss Raclette Toastie", "🍩 Bread Ahead Boston Cream Doughnuts", "☕ Monmouth Coffee Roasters", "🏙️ The Shard Observation View")
                ),
                DestinationSpot(
                    name = "Covent Garden & West End Theatre District",
                    category = "🎉 Nightlife & Shopping",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "West End",
                    durationMinutes = 150,
                    estimatedCostUSD = 60.0,
                    description = "Lively 19th-century glass piazza with world-class street buskers, boutique shopping, and legendary West End musical theatres.",
                    tags = listOf("Nightlife", "Shopping", "Culture", "Family"),
                    bestTimeOfDay = "Night",
                    nearbySuggestions = listOf("🎭 Les Misérables / Phantom of the Opera", "🍸 Rules Oldest Restaurant in London (1798)", "🛍️ Neal's Yard Colorful Courtyard", "☕ Dishoom Covent Garden Chai")
                ),
                DestinationSpot(
                    name = "British Museum & Great Court",
                    category = "🎨 World History & Artifacts",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Bloomsbury",
                    durationMinutes = 150,
                    estimatedCostUSD = 0.0,
                    description = "Monumental free public museum housing the Rosetta Stone, Parthenon Sculptures, and Egyptian mummies beneath Norman Foster's glass roof.",
                    tags = listOf("History", "Culture", "Family", "Sightseeing"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("☕ Museum Court Café", "📚 Russell Square Gardens", "🍜 Museum Street Classic Fish & Chips")
                ),
                DestinationSpot(
                    name = "Notting Hill & Portobello Road Antiques",
                    category = "💎 Colorful Neighborhood",
                    priorityBadge = "💎 HIDDEN GEM",
                    zone = "Kensington & Chelsea",
                    durationMinutes = 120,
                    estimatedCostUSD = 12.0,
                    description = "Pastel townhouse avenues, vintage antique stalls, indie bookshops, and cozy neighborhood brunch bistros.",
                    tags = listOf("Hidden gems", "Romantic", "Photography", "Cafés", "Shopping"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("☕ Farm Girl Organic Rose Latte Café", "🛍️ Alice's Antique Shop on Portobello", "📸 St Luke's Mews pastel houses")
                )
            )
        ),
        DestinationData(
            id = "switzerland",
            name = "Switzerland (Interlaken & Alps)",
            country = "Switzerland",
            region = "Central Europe",
            localCurrency = CurrencyInfo("CHF", "Swiss Franc", "CHF", 0.88),
            typicalDailyCostUSD = 180.0,
            isInternationalForINR = true,
            bestSeasons = "Jun - Sep (Alpine hiking) & Dec - Mar (Winter snow wonderland)",
            highlights = listOf("Jungfraujoch Top of Europe", "Lauterbrunnen 72 waterfalls valley", "Lake Brienz & Thun turquoise cruise", "Zermatt Matterhorn"),
            spots = listOf(
                DestinationSpot(
                    name = "Jungfraujoch: Top of Europe High Alpine Station",
                    category = "🏔️ Glacier & Alpine Wonder",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Jungfrau Region",
                    durationMinutes = 240,
                    estimatedCostUSD = 140.0,
                    description = "Europe's highest railway station (3,454m), Sphinx observatory overlooking the vast Aletsch Glacier and Ice Palace caverns.",
                    tags = listOf("Adventure", "Sightseeing", "Photography", "Family"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🧊 Ice Palace Sculptures Walk", "☕ Sphinx Panorama Alpine Restaurant", "🚠 Eiger Express Tri-cable Gondola", "🍫 Lindt Swiss Chocolate Heaven Experience")
                ),
                DestinationSpot(
                    name = "Lauterbrunnen Valley of 72 Waterfalls & Staubbach Falls",
                    category = "🌿 Fairytale Alpine Valley",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Lauterbrunnen",
                    durationMinutes = 150,
                    estimatedCostUSD = 10.0,
                    description = "U-shaped glacier valley fringed with sheer 300m rock walls and tumbling waterfalls, the inspiration for Tolkien's Rivendell.",
                    tags = listOf("Nature", "Photography", "Romantic", "Sightseeing"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("💦 Trümmelbach Falls inside mountain caverns", "☕ Flavours Café & Bakery", "🚠 Cable car to car-free Mürren village", "🥾 Valley floor wildflower walk")
                ),
                DestinationSpot(
                    name = "Lake Brienz Turquoise Steamer Cruise & Iseltwald",
                    category = "🌅 Scenic Lake Cruise",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Interlaken / Brienz",
                    durationMinutes = 120,
                    estimatedCostUSD = 35.0,
                    description = "Glacial turquoise lake steamer ride to the romantic Iseltwald castle pier (famous Korean drama landing point).",
                    tags = listOf("Sunset spot", "Romantic", "Photography", "Relaxed"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("📸 Famous Iseltwald Wooden Pier", "💦 Giessbach Falls & Historic Grand Hotel", "☕ Strandhotel Lakeview Fish Terrace", "🚠 Harder Kulm panoramic funicular")
                ),
                DestinationSpot(
                    name = "Harder Kulm: Two Lakes Bridge Viewpoint",
                    category = "🌅 Sunset & Viewpoint",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "Interlaken",
                    durationMinutes = 90,
                    estimatedCostUSD = 32.0,
                    description = "Funicular ascent above Interlaken with a glass-bottomed cantilever skywalk showing Eiger, Mönch, Jungfrau and both lakes.",
                    tags = listOf("Sunset spot", "Sightseeing", "Photography", "Romantic"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("🧀 Swiss Traditional Cheese Fondue at Panorama Restaurant", "📸 Glass Skywalk photo edge", "🥾 Alpine Ridge Sunset Path")
                ),
                DestinationSpot(
                    name = "Grindelwald First Cliff Walk & Mountain Carts",
                    category = "🏔️ Mountain Adventure",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "Grindelwald",
                    durationMinutes = 180,
                    estimatedCostUSD = 65.0,
                    description = "Suspension walkway suspended over sheer abyss, First Glider zipline, and fun gravity mountain cart descent to Bort.",
                    tags = listOf("Adventure", "Activities", "Photography", "Family"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🥾 Lake Bachalpsee Mirror Reflection Hike", "🏎️ Mountain Cart Trail downhill", "☕ Berggasthaus First Terrace")
                ),
                DestinationSpot(
                    name = "Gimmelwald Car-Free Quiet Alpine Hamlet",
                    category = "💎 Hidden Gem & Swiss Traditions",
                    priorityBadge = "💎 HIDDEN GEM",
                    zone = "Schilthorn Area",
                    durationMinutes = 90,
                    estimatedCostUSD = 15.0,
                    description = "Pristine mountain farming village without motor vehicles; honesty cheese fridges, flower-box wooden chalets, and bell cows.",
                    tags = listOf("Hidden gems", "Nature", "Wellness", "Relaxed"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("🧀 Farmhouse Self-Service Honesty Cheese Shop", "☕ Mountain Hostel Beer Garden with Eiger views", "🥾 Northface Trail to Mürren")
                )
            )
        ),
        DestinationData(
            id = "kerala",
            name = "Kerala",
            country = "India",
            region = "South Asia",
            localCurrency = CurrencyInfo("INR", "Indian Rupee", "₹", 86.5),
            typicalDailyCostUSD = 40.0,
            isInternationalForINR = false,
            bestSeasons = "Oct - Mar (Cool misty hills & serene backwaters)",
            highlights = listOf("Alleppey Houseboat Backwater Cruise", "Munnar Tea Plantations", "Fort Kochi Colonial Heritage", "Varkala Cliff Beach"),
            spots = listOf(
                DestinationSpot(
                    name = "Alleppey (Alappuzha) Private Houseboat Cruise",
                    category = "🌿 Backwaters & Relaxed",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Alleppey",
                    durationMinutes = 300,
                    estimatedCostUSD = 40.0,
                    description = "Drifting along tranquil palm-fringed canals, paddy fields, and lagoons with freshly prepared Karimeen fish curry.",
                    tags = listOf("Relaxed", "Romantic", "Nature", "Food", "Family"),
                    bestTimeOfDay = "Afternoon",
                    nearbySuggestions = listOf("🛶 Village Canoe Kayak Canal Tour", "🥥 Fresh Toddy & Duck Roast Shack", "🌅 Vembanad Lake Sunset Point", "🏖️ Alleppey Beach & Old Pier")
                ),
                DestinationSpot(
                    name = "Munnar Kolukkumalai Sunrise & Tea Gardens",
                    category = "🌅 Sunrise & Nature",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Munnar",
                    durationMinutes = 180,
                    estimatedCostUSD = 15.0,
                    description = "World's highest organic tea plantation (7,900ft) with jaw-dropping sea-of-clouds sunrise over Western Ghats peaks.",
                    tags = listOf("Sunrise spot", "Nature", "Photography", "Adventure"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("☕ Tea Museum & Tasting Session", "🥾 Top Station Cloud Viewpoint", "🌸 Eravikulam National Park (Nilgiri Tahr)", "💦 Attukad Waterfall Stop")
                ),
                DestinationSpot(
                    name = "Fort Kochi Chinese Fishing Nets & Heritage Walk",
                    category = "🏛️ Heritage & Art",
                    priorityBadge = "⭐ MUST VISIT",
                    zone = "Kochi / Ernakulam",
                    durationMinutes = 120,
                    estimatedCostUSD = 5.0,
                    description = "Iconic cantilevered shore-operated fishing nets introduced by 14th-century traders, colonial lanes, and spice warehouses.",
                    tags = listOf("Culture", "History", "Photography", "Cafés"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("☕ Kashi Art Café with Chocolate Cake", "🏛️ Mattancherry Dutch Palace & Jew Town", "🎭 Kerala Kathakali Center Live Performance", "🛍️ Spice Market Cardamom & Cinnamon")
                ),
                DestinationSpot(
                    name = "Varkala Cliff Beach & Arabian Sea Sunset",
                    category = "🏖️ Beach & Wellness",
                    priorityBadge = "🔥 VERY POPULAR",
                    zone = "Varkala (South Kerala)",
                    durationMinutes = 150,
                    estimatedCostUSD = 10.0,
                    description = "Dramatic red laterite cliffs towering over the Arabian Sea, clifftop cafes, yoga shalas, and sacred Papanasam mineral springs.",
                    tags = listOf("Beach", "Sunset spot", "Wellness", "Cafés", "Relaxed"),
                    bestTimeOfDay = "Sunset",
                    nearbySuggestions = listOf("☕ Coffee Temple & Tibetan Kitchen", "🧘 Clifftop Sunset Yoga Sessions", "🌊 Black Sand Beach Cove", "🛕 Janardhana Swamy 2,000yr Temple")
                ),
                DestinationSpot(
                    name = "Periyar Wildlife Sanctuary Bamboo Rafting",
                    category = "🌿 Nature & Adventure",
                    priorityBadge = "👍 WORTH VISITING",
                    zone = "Thekkady",
                    durationMinutes = 240,
                    estimatedCostUSD = 30.0,
                    description = "Dawn bamboo rafting and jungle trek through evergreen tiger reserve spotting wild elephant herds and otters.",
                    tags = listOf("Adventure", "Nature", "Family"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🐘 Elephant Junction & Spice Gardens", "🥊 Kalaripayattu Ancient Martial Arts Show", "🛍️ Organic Pepper & Cardamom Farms")
                ),
                DestinationSpot(
                    name = "Marari Quiet Coconut Beach Village",
                    category = "💎 Hidden Gem & Serenity",
                    priorityBadge = "💎 HIDDEN GEM",
                    zone = "Mararikulam",
                    durationMinutes = 120,
                    estimatedCostUSD = 8.0,
                    description = "Pristine white sand village beach away from commercial hustle, peaceful coconut groves, and traditional fishermen boats.",
                    tags = listOf("Hidden gems", "Beach", "Romantic", "Relaxed"),
                    bestTimeOfDay = "Morning",
                    nearbySuggestions = listOf("🥥 Beachside Fresh Coconut Water", "💆 Traditional Ayurvedic Abhyanga Massage", "🍴 Fresh Catch Seafood Homestay Dining")
                )
            )
        )
    )

    fun getPopularDestinations(): List<DestinationData> = DESTINATIONS

    fun findDestination(query: String): DestinationData? {
        val clean = query.trim().lowercase()
        return DESTINATIONS.find {
            it.name.lowercase().contains(clean) ||
            it.country.lowercase().contains(clean) ||
            clean.contains(it.name.lowercase()) ||
            it.id.equals(clean, ignoreCase = true)
        }
    }

    fun getOrSynthesizeDestination(destinationName: String, userStyles: List<String>): DestinationData {
        val existing = findDestination(destinationName)
        if (existing != null) return existing

        val isLikelyIndia = destinationName.contains("India", ignoreCase = true) ||
                listOf("mumbai", "delhi", "jaipur", "udaipur", "varanasi", "ladakh", "manali", "bangalore", "chennai", "kolkata", "hyderabad", "shimla", "agra", "rishikesh", "pondicherry", "ooty", "coorg", "darjeeling")
                    .any { destinationName.contains(it, ignoreCase = true) }

        val defaultCurrency = if (isLikelyIndia) {
            CurrencyInfo("INR", "Indian Rupee", "₹", 86.5)
        } else {
            CurrencyInfo("USD", "US Dollar", "$", 1.0)
        }

        val nameFormatted = destinationName.trim().replaceFirstChar { it.uppercase() }

        val synthesizedSpots = mutableListOf<DestinationSpot>()

        synthesizedSpots.add(
            DestinationSpot(
                name = "$nameFormatted Heritage & Old Town Center",
                category = "🏛️ Historic & Cultural",
                priorityBadge = "⭐ MUST VISIT",
                zone = "Historic Quarter",
                durationMinutes = 120,
                estimatedCostUSD = 15.0,
                description = "Explore the central historic district, iconic architectural monuments, and cultural landmarks of $nameFormatted.",
                tags = listOf("History", "Culture", "Sightseeing", "Photography"),
                bestTimeOfDay = "Morning",
                nearbySuggestions = listOf("☕ Historic Plaza Café", "🏛️ Local Heritage Museum", "🛍️ Artisan Souvenir Alley", "🍜 Authentic Traditional Eatery")
            )
        )

        synthesizedSpots.add(
            DestinationSpot(
                name = "$nameFormatted Panoramic Sunset Viewpoint",
                category = "🌅 Sunset & Viewpoint",
                priorityBadge = "📸 PHOTO SPOT",
                zone = "Scenic Heights",
                durationMinutes = 90,
                estimatedCostUSD = 5.0,
                description = "Unmatched elevated sunset vantage point overlooking the beautiful cityscape and surrounding landscape of $nameFormatted.",
                tags = listOf("Sunset spot", "Romantic", "Photography", "Sightseeing"),
                bestTimeOfDay = "Sunset",
                nearbySuggestions = listOf("🍹 Sunset Terrace Lounge", "📸 Panoramic Photo Platform", "☕ Hilltop Tea Stall", "🍴 Candlelit View Restaurant")
            )
        )

        synthesizedSpots.add(
            DestinationSpot(
                name = "$nameFormatted Famous Food Street & Night Market",
                category = "🍜 Food & Culinary",
                priorityBadge = "🔥 VERY POPULAR",
                zone = "Downtown Central",
                durationMinutes = 120,
                estimatedCostUSD = 20.0,
                description = "Savor celebrated local delicacies, street eats, regional desserts, and vibrant evening culinary stalls.",
                tags = listOf("Food", "Nightlife", "Culture", "Shopping"),
                bestTimeOfDay = "Night",
                nearbySuggestions = listOf("🍜 Famous Local Specialty Stall", "🍨 Regional Sweets & Gelato", "🛍️ Night Bazaar Crafts", "🎉 Live Music Tavern")
            )
        )

        synthesizedSpots.add(
            DestinationSpot(
                name = "$nameFormatted Nature Oasis & Botanical Park",
                category = "🌿 Nature & Relaxation",
                priorityBadge = "👍 WORTH VISITING",
                zone = "Green Belt",
                durationMinutes = 90,
                estimatedCostUSD = 5.0,
                description = "Peaceful lush gardens, walking trails, and fresh air sanctuary away from urban hustle.",
                tags = listOf("Nature", "Relaxed", "Wellness", "Family"),
                bestTimeOfDay = "Morning",
                nearbySuggestions = listOf("☕ Greenhouse Garden Café", "🚶 Scenic Lake Loop Trail", "📸 Floral Canopy Photo Spot")
            )
        )

        synthesizedSpots.add(
            DestinationSpot(
                name = "$nameFormatted Hidden Artisan Quarter",
                category = "💎 Hidden Gem",
                priorityBadge = "💎 HIDDEN GEM",
                zone = "East Quarter",
                durationMinutes = 90,
                estimatedCostUSD = 10.0,
                description = "Authentic lesser-known neighborhood featuring indie workshops, local craftspeople, and quiet courtyards.",
                tags = listOf("Hidden gems", "Culture", "Shopping", "Cafés", "Romantic"),
                bestTimeOfDay = "Afternoon",
                nearbySuggestions = listOf("☕ Hidden Specialty Roastery", "🎨 Local Pottery & Craft Studio", "🍷 Boutique Wine & Cheese Bar")
            )
        )

        synthesizedSpots.add(
            DestinationSpot(
                name = "$nameFormatted Landmark Waterfront / Main Boulevard",
                category = "🏖️ Promenade & Sightseeing",
                priorityBadge = "🔥 VERY POPULAR",
                zone = "Waterfront / Main Avenue",
                durationMinutes = 120,
                estimatedCostUSD = 12.0,
                description = "Vibrant open-air promenade ideal for leisurely strolls, shopping, and taking in local life.",
                tags = listOf("Sightseeing", "Beach", "Shopping", "Mixed"),
                bestTimeOfDay = "Afternoon",
                nearbySuggestions = listOf("☕ Waterfront Boardwalk Café", "🛍️ Local Fashion Boutiques", "🍦 Artisanal Gelateria", "🛥️ Scenic Boat Tour Pier")
            )
        )

        return DestinationData(
            id = nameFormatted.lowercase().replace(" ", "_"),
            name = nameFormatted,
            country = if (isLikelyIndia) "India" else "Worldwide Destination",
            region = "Global",
            localCurrency = defaultCurrency,
            typicalDailyCostUSD = 65.0,
            isInternationalForINR = !isLikelyIndia,
            bestSeasons = "Spring & Autumn (Ideal pleasant sightseeing weather)",
            highlights = listOf("$nameFormatted Historic Old Town", "Scenic Sunset Views", "Local Food Markets", "Artisan Culture"),
            spots = synthesizedSpots
        )
    }
}
