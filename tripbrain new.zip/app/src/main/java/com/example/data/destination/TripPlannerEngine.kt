package com.example.data.destination

import com.example.data.model.BudgetAllocation
import com.example.data.model.ItineraryActivityEntity
import com.example.data.model.ItineraryDayEntity
import com.example.data.model.NearbyRecommendation
import com.example.data.model.PackingItemEntity
import com.example.data.model.TravelPrepItem
import com.example.data.model.TripEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class GeneratedTripPlan(
    val trip: TripEntity,
    val days: List<ItineraryDayEntity>,
    val activities: List<ItineraryActivityEntity>,
    val packingItems: List<PackingItemEntity>,
    val prepItems: List<TravelPrepItem>,
    val destinationData: DestinationData
)

data class HotelBudgetRecommendation(
    val totalBudget: Double,
    val recommendedHotelTotalMin: Double,
    val recommendedHotelTotalMax: Double,
    val defaultHotelBudget: Double,
    val nightlyBudget: Double,
    val remainingBudget: Double
)

object TripPlannerEngine {

    fun calculateHotelBudget(totalBudget: Double, numNights: Int, currentHotelBudget: Double? = null): HotelBudgetRecommendation {
        val nights = if (numNights <= 0) 1 else numNights
        val minRatio = 0.25
        val maxRatio = 0.35

        val recMin = totalBudget * minRatio
        val recMax = totalBudget * maxRatio
        val selectedHotel = currentHotelBudget ?: (totalBudget * 0.30)
        val validHotel = selectedHotel.coerceIn(0.0, totalBudget)
        val nightly = validHotel / nights
        val remaining = (totalBudget - validHotel).coerceAtLeast(0.0)

        return HotelBudgetRecommendation(
            totalBudget = totalBudget,
            recommendedHotelTotalMin = recMin,
            recommendedHotelTotalMax = recMax,
            defaultHotelBudget = validHotel,
            nightlyBudget = nightly,
            remainingBudget = remaining
        )
    }

    fun getBudgetAllocations(totalBudget: Double, hotelBudget: Double, currencySymbol: String): List<BudgetAllocation> {
        val remaining = (totalBudget - hotelBudget).coerceAtLeast(0.0)

        // Divide remaining among other categories
        val flightTransport = (remaining * 0.35).coerceAtLeast(0.0)
        val foodDining = (remaining * 0.28).coerceAtLeast(0.0)
        val localTransport = (remaining * 0.12).coerceAtLeast(0.0)
        val activities = (remaining * 0.15).coerceAtLeast(0.0)
        val shopping = (remaining * 0.05).coerceAtLeast(0.0)
        val emergency = (remaining * 0.05).coerceAtLeast(0.0)

        return listOf(
            BudgetAllocation("🏨 Hotel / Stay", hotelBudget, "$currencySymbol${String.format(Locale.US, "%,.0f", hotelBudget)}", "30%"),
            BudgetAllocation("✈️ Flights / Major Transport", flightTransport, "$currencySymbol${String.format(Locale.US, "%,.0f", flightTransport)}", "25%"),
            BudgetAllocation("🍜 Food & Dining", foodDining, "$currencySymbol${String.format(Locale.US, "%,.0f", foodDining)}", "20%"),
            BudgetAllocation("🚕 Local Transit / Cabs", localTransport, "$currencySymbol${String.format(Locale.US, "%,.0f", localTransport)}", "8%"),
            BudgetAllocation("🎟️ Sightseeing & Activities", activities, "$currencySymbol${String.format(Locale.US, "%,.0f", activities)}", "10%"),
            BudgetAllocation("🛍️ Shopping & Souvenirs", shopping, "$currencySymbol${String.format(Locale.US, "%,.0f", shopping)}", "4%"),
            BudgetAllocation("🆘 Emergency Buffer", emergency, "$currencySymbol${String.format(Locale.US, "%,.0f", emergency)}", "3%")
        )
    }

    fun planTrip(
        destinationName: String,
        startDateMillis: Long,
        endDateMillis: Long,
        totalBudget: Double,
        currencyCode: String,
        currencySymbol: String,
        travellers: String,
        selectedStyles: List<String>
    ): GeneratedTripPlan {
        val millisPerDay = 24 * 60 * 60 * 1000L
        val diffMillis = (endDateMillis - startDateMillis).coerceAtLeast(0L)
        val numDays = ((diffMillis / millisPerDay) + 1).toInt().coerceIn(1, 30)
        val numNights = (numDays - 1).coerceAtLeast(1)

        val destinationData = DestinationKnowledgeEngine.getOrSynthesizeDestination(destinationName, selectedStyles)

        // Hotel default 30%
        val defaultHotel = totalBudget * 0.30

        val trip = TripEntity(
            destination = destinationData.name,
            country = destinationData.country,
            startDateMillis = startDateMillis,
            endDateMillis = endDateMillis,
            numDays = numDays,
            numNights = numNights,
            totalBudget = totalBudget,
            currencyCode = currencyCode,
            currencySymbol = currencySymbol,
            travellersCount = travellers,
            travelStyles = selectedStyles.joinToString(","),
            hotelBudget = defaultHotel,
            status = "Upcoming"
        )

        // Currency exchange conversion rate factor
        val currencyObj = DestinationKnowledgeEngine.CURRENCIES.find { it.code.equals(currencyCode, ignoreCase = true) }
            ?: DestinationKnowledgeEngine.CURRENCIES.first()
        val usdToUserCurrency = currencyObj.approximateRateToUSD

        // Filter and prioritize spots
        val allSpots = destinationData.spots
        val styleMatchedSpots = allSpots.filter { spot ->
            selectedStyles.isEmpty() || spot.tags.any { tag ->
                selectedStyles.any { style -> style.contains(tag, ignoreCase = true) || tag.contains(style, ignoreCase = true) }
            }
        }.ifEmpty { allSpots }

        // Group by zone to minimize transit
        val spotsByZone = styleMatchedSpots.groupBy { it.zone }
        val zones = spotsByZone.keys.toList()

        val days = mutableListOf<ItineraryDayEntity>()
        val activities = mutableListOf<ItineraryActivityEntity>()

        val timeSlots = listOf(
            Triple("09:00 AM", "Morning", 90),
            Triple("11:30 AM", "Morning", 90),
            Triple("01:30 PM", "Afternoon", 75), // Lunch / Midday
            Triple("03:30 PM", "Afternoon", 100),
            Triple("06:00 PM", "Sunset", 90), // Sunset
            Triple("08:30 PM", "Night", 120) // Nightlife / Dinner
        )

        val themeTemplates = listOf(
            "Iconic Landmarks & Sunset Vistas",
            "Local Culture, Hidden Lanes & Culinary Spots",
            "Nature Trails & Waterfront Relaxation",
            "Vibrant Markets, Shopping & Nightlife",
            "Heritage Architecture & Scenic Cafés",
            "Island Adventure & Secret Coastal Gems",
            "Slow Living, Wellness & Sunset Dinner"
        )

        for (dayIndex in 1..numDays) {
            val dayEpoch = startDateMillis + (dayIndex - 1) * millisPerDay
            val theme = themeTemplates[(dayIndex - 1) % themeTemplates.size]

            days.add(
                ItineraryDayEntity(
                    tripId = 0,
                    dayNumber = dayIndex,
                    dateEpochMillis = dayEpoch,
                    dayTheme = "Day $dayIndex: $theme",
                    dayNotes = ""
                )
            )

            // Pick zone for this day
            val zoneForDay = if (zones.isNotEmpty()) zones[(dayIndex - 1) % zones.size] else "Central District"
            val candidateSpotsInZone = (spotsByZone[zoneForDay] ?: emptyList()).toMutableList()
            val remainingSpots = (allSpots - candidateSpotsInZone.toSet()).toMutableList()

            // Generate 4-5 activities per day
            val daySpots = mutableListOf<DestinationSpot>()
            daySpots.addAll(candidateSpotsInZone.take(3))
            val needed = 4 - daySpots.size
            if (needed > 0) {
                daySpots.addAll(remainingSpots.take(needed))
            }
            if (daySpots.isEmpty()) {
                daySpots.addAll(allSpots.take(4))
            }

            daySpots.forEachIndexed { actIndex, spot ->
                val slot = timeSlots[actIndex.coerceAtMost(timeSlots.size - 1)]
                val costInUserCurrency = spot.estimatedCostUSD * usdToUserCurrency

                val nearbyJoined = spot.nearbySuggestions.joinToString(" • ")

                activities.add(
                    ItineraryActivityEntity(
                        tripId = 0,
                        dayNumber = dayIndex,
                        placeName = spot.name,
                        category = spot.category,
                        timeSlot = slot.first,
                        durationMinutes = spot.durationMinutes,
                        travelTimeMinutes = if (actIndex == 0) 10 else 15,
                        estimatedCost = costInUserCurrency,
                        description = spot.description,
                        priorityBadge = spot.priorityBadge,
                        isVisited = false,
                        locationZone = spot.zone,
                        nearbySuggestionsJson = nearbyJoined
                    )
                )
            }
        }

        // Smart Packing list
        val packingList = generatePackingList(destinationData, numDays, selectedStyles)

        // Travel preparation checklist
        val prepList = generateTravelPrep(destinationData, currencyCode)

        return GeneratedTripPlan(
            trip = trip,
            days = days,
            activities = activities,
            packingItems = packingList,
            prepItems = prepList,
            destinationData = destinationData
        )
    }

    private fun generatePackingList(
        destination: DestinationData,
        numDays: Int,
        styles: List<String>
    ): List<PackingItemEntity> {
        val items = mutableListOf<PackingItemEntity>()

        // Essential Documents
        items.add(PackingItemEntity(tripId = 0, name = "Passport & National ID copies", category = "🪪 Documents", isChecked = false, isEssential = true))
        items.add(PackingItemEntity(tripId = 0, name = "Flight & Hotel Confirmation PDFs", category = "🪪 Documents", isChecked = false, isEssential = true))
        items.add(PackingItemEntity(tripId = 0, name = "International Travel Insurance card", category = "🪪 Documents", isChecked = false, isEssential = true))
        items.add(PackingItemEntity(tripId = 0, name = "Forex / Credit Cards & Cash backup", category = "🪪 Documents", isChecked = false, isEssential = true))

        // Clothes based on duration
        val shirtsCount = (numDays + 1).coerceAtMost(8)
        items.add(PackingItemEntity(tripId = 0, name = "$shirtsCount Lightweight T-shirts & Shirts", category = "👕 Clothes & Footwear", isChecked = false))
        items.add(PackingItemEntity(tripId = 0, name = "2-3 Pairs of Shorts / Breathable Pants", category = "👕 Clothes & Footwear", isChecked = false))
        items.add(PackingItemEntity(tripId = 0, name = "Comfortable Walking Sneakers / Shoes", category = "👕 Clothes & Footwear", isChecked = false, isEssential = true))
        items.add(PackingItemEntity(tripId = 0, name = "Flip-flops / Beach Sandals", category = "👕 Clothes & Footwear", isChecked = false))
        items.add(PackingItemEntity(tripId = 0, name = "Undergarments & Socks for $numDays days", category = "👕 Clothes & Footwear", isChecked = false))

        // Style specific items
        val hasBeach = styles.any { it.contains("Beach", ignoreCase = true) || it.contains("Relaxed", ignoreCase = true) }
        val hasAdventure = styles.any { it.contains("Adventure", ignoreCase = true) || it.contains("Nature", ignoreCase = true) }

        if (hasBeach || destination.spots.any { it.category.contains("Beach", ignoreCase = true) }) {
            items.add(PackingItemEntity(tripId = 0, name = "Swimwear & Rashguard", category = "🏊 Beach & Activities", isChecked = false))
            items.add(PackingItemEntity(tripId = 0, name = "High SPF Broad-Spectrum Sunscreen", category = "🧴 Toiletries", isChecked = false, isEssential = true))
            items.add(PackingItemEntity(tripId = 0, name = "Quick-dry Microfiber Beach Towel", category = "🏊 Beach & Activities", isChecked = false))
            items.add(PackingItemEntity(tripId = 0, name = "UV Sunglasses & Sun Hat", category = "🏊 Beach & Activities", isChecked = false))
            items.add(PackingItemEntity(tripId = 0, name = "Waterproof Phone Pouch", category = "🔌 Electronics", isChecked = false))
        }

        if (hasAdventure || destination.name.contains("Switzerland", ignoreCase = true)) {
            items.add(PackingItemEntity(tripId = 0, name = "Sturdy Trail / Hiking Shoes", category = "👕 Clothes & Footwear", isChecked = false))
            items.add(PackingItemEntity(tripId = 0, name = "Windbreaker / Waterproof Jacket", category = "👕 Clothes & Footwear", isChecked = false, isEssential = true))
            items.add(PackingItemEntity(tripId = 0, name = "Compact Day Backpack (15-20L)", category = "🏊 Beach & Activities", isChecked = false))
            items.add(PackingItemEntity(tripId = 0, name = "Insect Repellent Spray", category = "🧴 Toiletries", isChecked = false))
        }

        // Electronics
        items.add(PackingItemEntity(tripId = 0, name = "Phone Charger & High-speed Cables", category = "🔌 Electronics", isChecked = false, isEssential = true))
        items.add(PackingItemEntity(tripId = 0, name = "10,000+ mAh Portable Power Bank", category = "🔌 Electronics", isChecked = false, isEssential = true))
        items.add(PackingItemEntity(tripId = 0, name = "Universal Travel Power Plug Adapter", category = "🔌 Electronics", isChecked = false, isEssential = true))
        items.add(PackingItemEntity(tripId = 0, name = "Noise-Cancelling Earbuds / Headphones", category = "🔌 Electronics", isChecked = false))

        // Toiletries & Meds
        items.add(PackingItemEntity(tripId = 0, name = "Toothbrush, Paste & Mini Floss", category = "🧴 Toiletries", isChecked = false))
        items.add(PackingItemEntity(tripId = 0, name = "Hydrating Moisturizer & Lip Balm", category = "🧴 Toiletries", isChecked = false))
        items.add(PackingItemEntity(tripId = 0, name = "Personal Medication & Pain Relief (Paracetamol)", category = "💊 Health & First Aid", isChecked = false, isEssential = true))
        items.add(PackingItemEntity(tripId = 0, name = "Band-Aids & Antiseptic Wipes", category = "💊 Health & First Aid", isChecked = false))
        items.add(PackingItemEntity(tripId = 0, name = "Electrolyte / ORS sachets for hydration", category = "💊 Health & First Aid", isChecked = false))

        return items
    }

    private fun generateTravelPrep(destination: DestinationData, userCurrencyCode: String): List<TravelPrepItem> {
        val list = mutableListOf<TravelPrepItem>()

        if (destination.isInternationalForINR) {
            list.add(
                TravelPrepItem(
                    title = "Visa & Passport Validity",
                    category = "🛂 Entry Requirements",
                    icon = "🪪",
                    description = "Ensure passport has at least 6 months validity from return date and 2 blank pages. Verify eVisa / Visa on Arrival requirements for ${destination.country}."
                )
            )
            list.add(
                TravelPrepItem(
                    title = "International eSIM / Roaming",
                    category = "📶 Connectivity",
                    icon = "📶",
                    description = "Download an international eSIM (Airalo / Nomad) or purchase a local 5G travel SIM at ${destination.name} airport for reliable navigation."
                )
            )
            list.add(
                TravelPrepItem(
                    title = "Forex & Zero-Markup Card",
                    category = "💱 Currency Exchange",
                    icon = "💳",
                    description = "Local currency is ${destination.localCurrency.code} (${destination.localCurrency.symbol}). Enable international usage on credit/debit cards and keep a small cash buffer."
                )
            )
            list.add(
                TravelPrepItem(
                    title = "Travel Health & Baggage Insurance",
                    category = "🛡️ Safety",
                    icon = "🛡️",
                    description = "Secure comprehensive travel policy covering emergency medical treatments, flight delays, and lost luggage."
                )
            )
        } else {
            list.add(
                TravelPrepItem(
                    title = "Government ID & Hotel Check-in",
                    category = "🪪 Domestic Travel",
                    icon = "🪪",
                    description = "Keep original Aadhaar / Driving License handy for airport and hotel entry."
                )
            )
            list.add(
                TravelPrepItem(
                    title = "Offline Maps & Local Cabs",
                    category = "🚕 Transit",
                    icon = "🗺️",
                    description = "Download Google Maps offline area for ${destination.name} and local ride-hailing apps."
                )
            )
        }

        list.add(
            TravelPrepItem(
                title = "Emergency Numbers & Embassy Contacts",
                category = "🆘 Safety",
                icon = "📞",
                description = "Save local emergency services (112 / Police / Ambulance) and hotel direct reception contacts."
            )
        )

        return list
    }

    fun getQuickMoodRecommendations(
        mood: String,
        destinationData: DestinationData,
        userCurrencySymbol: String,
        usdRate: Double
    ): List<NearbyRecommendation> {
        val spots = destinationData.spots

        val filtered = when (mood) {
            "🏖️ Beach" -> spots.filter { it.category.contains("Beach", ignoreCase = true) || it.tags.contains("Beach") }
            "🍜 Eat" -> spots.filter { it.category.contains("Food", ignoreCase = true) || it.tags.contains("Food") }
            "🎉 Party" -> spots.filter { it.category.contains("Nightlife", ignoreCase = true) || it.tags.contains("Nightlife") }
            "☕ Café" -> spots.filter { it.category.contains("Café", ignoreCase = true) || it.tags.contains("Cafés") || it.nearbySuggestions.any { s -> s.contains("Café", ignoreCase = true) } }
            "🌅 Sunset" -> spots.filter { it.category.contains("Sunset", ignoreCase = true) || it.tags.contains("Sunset spot") || it.bestTimeOfDay == "Sunset" }
            "🛍️ Shop" -> spots.filter { it.category.contains("Shopping", ignoreCase = true) || it.tags.contains("Shopping") || it.category.contains("Market", ignoreCase = true) }
            "🌿 Nature" -> spots.filter { it.category.contains("Nature", ignoreCase = true) || it.tags.contains("Nature") }
            "🏛️ Culture" -> spots.filter { it.category.contains("Historic", ignoreCase = true) || it.tags.contains("Culture") || it.tags.contains("History") }
            "🏔️ Adventure" -> spots.filter { it.category.contains("Adventure", ignoreCase = true) || it.tags.contains("Adventure") }
            "❤️ Date" -> spots.filter { it.tags.contains("Romantic") }
            "📸 Explore" -> spots.filter { it.priorityBadge == "⭐ MUST VISIT" || it.priorityBadge == "📸 PHOTO SPOT" }
            else -> spots
        }.ifEmpty { spots.take(3) }

        return filtered.take(4).map { spot ->
            val cost = spot.estimatedCostUSD * usdRate
            NearbyRecommendation(
                title = spot.name,
                category = spot.category,
                icon = spot.priorityBadge,
                distanceText = "${spot.zone} • ~${spot.durationMinutes} min",
                description = spot.description + " • Approx $userCurrencySymbol${String.format(Locale.US, "%,.0f", cost)}"
            )
        }
    }
}
