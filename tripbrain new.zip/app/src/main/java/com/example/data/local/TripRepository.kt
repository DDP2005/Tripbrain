package com.example.data.local

import com.example.data.model.BookingEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.ItineraryActivityEntity
import com.example.data.model.ItineraryDayEntity
import com.example.data.model.PackingItemEntity
import com.example.data.model.TripEntity
import kotlinx.coroutines.flow.Flow

class TripRepository(private val db: AppDatabase) {
    private val tripDao = db.tripDao()
    private val expenseDao = db.expenseDao()
    private val bookingDao = db.bookingDao()
    private val packingDao = db.packingDao()

    val allTrips: Flow<List<TripEntity>> = tripDao.getAllTrips()

    fun getTripById(id: Long): Flow<TripEntity?> = tripDao.getTripById(id)
    suspend fun getTripByIdOnce(id: Long): TripEntity? = tripDao.getTripByIdOnce(id)

    suspend fun createTrip(
        trip: TripEntity,
        days: List<ItineraryDayEntity>,
        activities: List<ItineraryActivityEntity>,
        packingItems: List<PackingItemEntity>
    ): Long {
        val tripId = tripDao.insertTrip(trip)
        val updatedDays = days.map { it.copy(tripId = tripId) }
        val updatedActivities = activities.map { it.copy(tripId = tripId) }
        val updatedPacking = packingItems.map { it.copy(tripId = tripId) }

        tripDao.insertDays(updatedDays)
        tripDao.insertActivities(updatedActivities)
        packingDao.insertPackingItems(updatedPacking)

        return tripId
    }

    suspend fun updateTrip(trip: TripEntity) = tripDao.updateTrip(trip)

    suspend fun deleteTripById(id: Long) {
        tripDao.deleteTripById(id)
        tripDao.deleteDaysForTrip(id)
        tripDao.deleteActivitiesForTrip(id)
        expenseDao.deleteExpensesForTrip(id)
        bookingDao.deleteBookingsForTrip(id)
        packingDao.deletePackingItemsForTrip(id)
    }

    // Itinerary Days & Activities
    fun getDaysForTrip(tripId: Long): Flow<List<ItineraryDayEntity>> = tripDao.getDaysForTrip(tripId)
    fun getActivitiesForTrip(tripId: Long): Flow<List<ItineraryActivityEntity>> = tripDao.getActivitiesForTrip(tripId)
    fun getActivitiesForDay(tripId: Long, dayNumber: Int): Flow<List<ItineraryActivityEntity>> = tripDao.getActivitiesForDay(tripId, dayNumber)

    suspend fun addActivity(activity: ItineraryActivityEntity): Long = tripDao.insertActivity(activity)
    suspend fun updateActivity(activity: ItineraryActivityEntity) = tripDao.updateActivity(activity)
    suspend fun deleteActivity(activity: ItineraryActivityEntity) = tripDao.deleteActivity(activity)
    suspend fun deleteActivityById(id: Long) = tripDao.deleteActivityById(id)

    // Expenses
    fun getExpensesForTrip(tripId: Long): Flow<List<ExpenseEntity>> = expenseDao.getExpensesForTrip(tripId)
    suspend fun addExpense(expense: ExpenseEntity): Long = expenseDao.insertExpense(expense)
    suspend fun deleteExpense(expense: ExpenseEntity) = expenseDao.deleteExpense(expense)

    // Bookings
    fun getBookingsForTrip(tripId: Long): Flow<List<BookingEntity>> = bookingDao.getBookingsForTrip(tripId)
    suspend fun addBooking(booking: BookingEntity): Long = bookingDao.insertBooking(booking)
    suspend fun deleteBooking(booking: BookingEntity) = bookingDao.deleteBooking(booking)

    // Packing
    fun getPackingItemsForTrip(tripId: Long): Flow<List<PackingItemEntity>> = packingDao.getPackingItemsForTrip(tripId)
    suspend fun addPackingItem(item: PackingItemEntity): Long = packingDao.insertPackingItem(item)
    suspend fun updatePackingItem(item: PackingItemEntity) = packingDao.updatePackingItem(item)
    suspend fun deletePackingItem(item: PackingItemEntity) = packingDao.deletePackingItem(item)
}
