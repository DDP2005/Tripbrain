package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BookingEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.ItineraryActivityEntity
import com.example.data.model.ItineraryDayEntity
import com.example.data.model.PackingItemEntity
import com.example.data.model.TripEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TripDao {
    @Query("SELECT * FROM trips ORDER BY createdAt DESC")
    fun getAllTrips(): Flow<List<TripEntity>>

    @Query("SELECT * FROM trips WHERE id = :id")
    fun getTripById(id: Long): Flow<TripEntity?>

    @Query("SELECT * FROM trips WHERE id = :id")
    suspend fun getTripByIdOnce(id: Long): TripEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrip(trip: TripEntity): Long

    @Update
    suspend fun updateTrip(trip: TripEntity)

    @Delete
    suspend fun deleteTrip(trip: TripEntity)

    @Query("DELETE FROM trips WHERE id = :id")
    suspend fun deleteTripById(id: Long)

    // Itinerary Days
    @Query("SELECT * FROM itinerary_days WHERE tripId = :tripId ORDER BY dayNumber ASC")
    fun getDaysForTrip(tripId: Long): Flow<List<ItineraryDayEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDays(days: List<ItineraryDayEntity>)

    @Query("DELETE FROM itinerary_days WHERE tripId = :tripId")
    suspend fun deleteDaysForTrip(tripId: Long)

    // Itinerary Activities
    @Query("SELECT * FROM itinerary_activities WHERE tripId = :tripId ORDER BY dayNumber ASC, timeSlot ASC")
    fun getActivitiesForTrip(tripId: Long): Flow<List<ItineraryActivityEntity>>

    @Query("SELECT * FROM itinerary_activities WHERE tripId = :tripId AND dayNumber = :dayNumber ORDER BY timeSlot ASC")
    fun getActivitiesForDay(tripId: Long, dayNumber: Int): Flow<List<ItineraryActivityEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivities(activities: List<ItineraryActivityEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivity(activity: ItineraryActivityEntity): Long

    @Update
    suspend fun updateActivity(activity: ItineraryActivityEntity)

    @Delete
    suspend fun deleteActivity(activity: ItineraryActivityEntity)

    @Query("DELETE FROM itinerary_activities WHERE id = :id")
    suspend fun deleteActivityById(id: Long)

    @Query("DELETE FROM itinerary_activities WHERE tripId = :tripId")
    suspend fun deleteActivitiesForTrip(tripId: Long)
}

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses WHERE tripId = :tripId ORDER BY dateMillis DESC")
    fun getExpensesForTrip(tripId: Long): Flow<List<ExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity): Long

    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity)

    @Query("DELETE FROM expenses WHERE tripId = :tripId")
    suspend fun deleteExpensesForTrip(tripId: Long)
}

@Dao
interface BookingDao {
    @Query("SELECT * FROM bookings WHERE tripId = :tripId ORDER BY startDateTimeMillis ASC")
    fun getBookingsForTrip(tripId: Long): Flow<List<BookingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: BookingEntity): Long

    @Delete
    suspend fun deleteBooking(booking: BookingEntity)

    @Query("DELETE FROM bookings WHERE tripId = :tripId")
    suspend fun deleteBookingsForTrip(tripId: Long)
}

@Dao
interface PackingDao {
    @Query("SELECT * FROM packing_items WHERE tripId = :tripId ORDER BY category ASC, id ASC")
    fun getPackingItemsForTrip(tripId: Long): Flow<List<PackingItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackingItems(items: List<PackingItemEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackingItem(item: PackingItemEntity): Long

    @Update
    suspend fun updatePackingItem(item: PackingItemEntity)

    @Delete
    suspend fun deletePackingItem(item: PackingItemEntity)

    @Query("DELETE FROM packing_items WHERE tripId = :tripId")
    suspend fun deletePackingItemsForTrip(tripId: Long)
}
