package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.BookingEntity
import com.example.data.model.ExpenseEntity
import com.example.data.model.ItineraryActivityEntity
import com.example.data.model.ItineraryDayEntity
import com.example.data.model.PackingItemEntity
import com.example.data.model.TripEntity

@Database(
    entities = [
        TripEntity::class,
        ItineraryDayEntity::class,
        ItineraryActivityEntity::class,
        ExpenseEntity::class,
        BookingEntity::class,
        PackingItemEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tripDao(): TripDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun bookingDao(): BookingDao
    abstract fun packingDao(): PackingDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "tripbrain_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
