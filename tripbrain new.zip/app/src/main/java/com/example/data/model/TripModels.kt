package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trips")
data class TripEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val destination: String,
    val country: String = "",
    val startDateMillis: Long,
    val endDateMillis: Long,
    val numDays: Int,
    val numNights: Int,
    val totalBudget: Double,
    val currencyCode: String = "INR",
    val currencySymbol: String = "₹",
    val travellersCount: String = "1",
    val travelStyles: String = "", // Comma separated e.g. "Beach,Food,Nightlife"
    val hotelBudget: Double = 0.0, // Specific allocated hotel budget
    val status: String = "Upcoming", // Planning, Upcoming, Ongoing, Completed
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "itinerary_days")
data class ItineraryDayEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tripId: Long,
    val dayNumber: Int,
    val dateEpochMillis: Long,
    val dayTheme: String,
    val dayNotes: String = ""
)

@Entity(tableName = "itinerary_activities")
data class ItineraryActivityEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tripId: Long,
    val dayNumber: Int,
    val placeName: String,
    val category: String, // Famous landmark, Beach, Food, Café, Nightlife, Culture, Sunset spot, etc.
    val timeSlot: String, // e.g. "09:00 AM"
    val durationMinutes: Int = 90,
    val travelTimeMinutes: Int = 15,
    val estimatedCost: Double = 0.0,
    val description: String = "",
    val priorityBadge: String = "⭐ MUST VISIT", // ⭐ MUST VISIT, 🔥 VERY POPULAR, 👍 WORTH VISITING, 📸 PHOTO SPOT, 💎 HIDDEN GEM
    val isVisited: Boolean = false,
    val locationZone: String = "", // e.g. "North Goa", "Shinjuku", "Louvre Area"
    val nearbySuggestionsJson: String = "" // formatted recommendations e.g. "Café: Bistro Parisien; Sunset: Pont des Arts"
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tripId: Long,
    val category: String, // 🍜 Food, 🚕 Transport, 🏨 Hotel, 🎟️ Activities, 🛍️ Shopping, 📦 Other
    val amount: Double,
    val currencySymbol: String,
    val description: String,
    val dateMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "bookings")
data class BookingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tripId: Long,
    val bookingType: String, // ✈️ Flight, 🚆 Train, 🚌 Bus, 🏨 Hotel, 🎟️ Activity
    val title: String,
    val bookingReference: String = "",
    val startDateTimeMillis: Long,
    val location: String = "",
    val price: Double = 0.0,
    val notes: String = ""
)

@Entity(tableName = "packing_items")
data class PackingItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tripId: Long,
    val name: String,
    val category: String, // Documents, Clothes, Toiletries, Electronics, Gear, Health
    val isChecked: Boolean = false,
    val isEssential: Boolean = false,
    val isCustom: Boolean = false
)

data class NearbyRecommendation(
    val title: String,
    val category: String,
    val icon: String,
    val distanceText: String,
    val description: String
)

data class CurrencyInfo(
    val code: String,
    val name: String,
    val symbol: String,
    val approximateRateToUSD: Double // 1 USD = X Currency
)

data class TravelPrepItem(
    val title: String,
    val category: String,
    val icon: String,
    val description: String,
    val isChecked: Boolean = false
)

data class BudgetAllocation(
    val category: String,
    val amount: Double,
    val formattedAmount: String,
    val percentage: String
)

