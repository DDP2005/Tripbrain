package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.destination.TripPlannerEngine
import com.example.data.model.ItineraryActivityEntity
import com.example.data.model.NearbyRecommendation
import com.example.ui.theme.CoralRed100
import com.example.ui.theme.CoralRed500
import com.example.ui.theme.OceanBlue600
import com.example.ui.theme.OceanBlue700
import com.example.ui.theme.OceanBlue800
import com.example.ui.theme.OceanBlue900
import com.example.ui.theme.SkyBlue200
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.SunsetAmber100
import com.example.ui.theme.SunsetAmber500
import com.example.ui.theme.SunsetAmber600
import com.example.ui.theme.TropicalTeal100
import com.example.ui.theme.TropicalTeal500
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PriorityBadgeView(badge: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor) = when {
        badge.contains("MUST VISIT") -> Pair(SunsetAmber100, SunsetAmber600)
        badge.contains("VERY POPULAR") -> Pair(Color(0xFFFFEDD5), Color(0xFFC2410C))
        badge.contains("PHOTO SPOT") -> Pair(SkyBlue200, OceanBlue800)
        badge.contains("HIDDEN GEM") -> Pair(TropicalTeal100, TropicalTeal500)
        else -> Pair(Slate100, Slate600)
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Text(
            text = badge,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun HotelBudgetSliderCard(
    totalBudget: Double,
    numNights: Int,
    currentHotelBudget: Double,
    currencySymbol: String,
    onBudgetChanged: (Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val rec = TripPlannerEngine.calculateHotelBudget(totalBudget, numNights, currentHotelBudget)
    var sliderValue by remember(currentHotelBudget, totalBudget) {
        mutableStateOf(currentHotelBudget.coerceIn(0.0, totalBudget).toFloat())
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("hotel_budget_slider_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(SunsetAmber100, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Hotel, contentDescription = null, tint = SunsetAmber600)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Hotel Budget Allocation",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$numNights nights stay",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate600
                        )
                    }
                }

                Surface(
                    color = OceanBlue900,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "$currencySymbol${String.format(Locale.US, "%,.0f", sliderValue.toDouble())}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Metric display row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Per Night", fontSize = 12.sp, color = Slate600)
                    val nightly = if (numNights > 0) sliderValue / numNights else sliderValue
                    Text(
                        "$currencySymbol${String.format(Locale.US, "%,.0f", nightly)}/night",
                        fontWeight = FontWeight.SemiBold,
                        color = OceanBlue800,
                        fontSize = 14.sp
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Recommended Range", fontSize = 12.sp, color = Slate600)
                    Text(
                        "$currencySymbol${String.format(Locale.US, "%,.0f", rec.recommendedHotelTotalMin)} - $currencySymbol${String.format(Locale.US, "%,.0f", rec.recommendedHotelTotalMax)}",
                        fontWeight = FontWeight.Medium,
                        color = TropicalTeal500,
                        fontSize = 13.sp
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("Remaining Budget", fontSize = 12.sp, color = Slate600)
                    val remaining = (totalBudget - sliderValue).coerceAtLeast(0.0)
                    Text(
                        "$currencySymbol${String.format(Locale.US, "%,.0f", remaining)}",
                        fontWeight = FontWeight.Bold,
                        color = if (remaining < totalBudget * 0.2) CoralRed500 else Slate800,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Interactive Touch Slider
            Slider(
                value = sliderValue,
                onValueChange = {
                    sliderValue = it
                    onBudgetChanged(it.toDouble())
                },
                valueRange = 0f..totalBudget.toFloat(),
                colors = SliderDefaults.colors(
                    thumbColor = SunsetAmber500,
                    activeTrackColor = OceanBlue600,
                    inactiveTrackColor = Slate200
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hotel_budget_slider")
            )

            // Warning if hotel budget is too high
            val hotelRatio: Double = if (totalBudget > 0.0) (sliderValue.toDouble() / totalBudget) else 0.0
            if (hotelRatio > 0.55) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CoralRed100, RoundedCornerShape(8.dp))
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = CoralRed500, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Hotel consumes ${String.format(Locale.US, "%.0f", hotelRatio * 100.0)}% of total budget. Consider keeping it below 40% for food & activities.",
                        fontSize = 11.sp,
                        color = CoralRed500,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun MoodRecommendationsSection(
    selectedMood: String,
    recommendations: List<NearbyRecommendation>,
    onMoodSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val moods = listOf(
        "🏖️ Beach", "🍜 Eat", "🎉 Party", "☕ Café", "🌅 Sunset",
        "📸 Explore", "🛍️ Shop", "🌿 Nature", "🏛️ Culture", "🏔️ Adventure", "❤️ Date", "🍹 Chill"
    )

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "What do you feel like doing?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Slate900
                )
                Text(
                    text = "Smart instant recommendations based on mood & location",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate600
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Horizontal Mood Selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            moods.forEach { mood ->
                val isSelected = mood == selectedMood
                FilterChip(
                    selected = isSelected,
                    onClick = { onMoodSelected(mood) },
                    label = {
                        Text(
                            text = mood,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = OceanBlue600,
                        selectedLabelColor = Color.White,
                        containerColor = Slate100,
                        labelColor = Slate800
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.testTag("mood_chip_$mood")
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Recommendation Cards
        if (recommendations.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                recommendations.forEach { item ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Slate100),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .background(Color.White, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(item.category.take(2), fontSize = 18.sp)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Slate900
                                )
                                Text(
                                    text = item.distanceText,
                                    fontSize = 12.sp,
                                    color = OceanBlue600,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = item.description,
                                    fontSize = 12.sp,
                                    color = Slate600,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ActivityTimelineCard(
    activity: ItineraryActivityEntity,
    totalDays: Int,
    currencySymbol: String,
    onToggleVisited: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onMoveToDay: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("activity_card_${activity.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (activity.isVisited) Color(0xFFF0FDF4) else Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Time, Visited, Badge, Overflow
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = if (activity.isVisited) TropicalTeal100 else Color(0xFFE0F2FE),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Schedule,
                                contentDescription = null,
                                tint = if (activity.isVisited) TropicalTeal500 else OceanBlue700,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = activity.timeSlot,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (activity.isVisited) TropicalTeal500 else OceanBlue700
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))
                    PriorityBadgeView(activity.priorityBadge)
                }

                Box {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Options", tint = Slate600)
                    }

                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text(if (activity.isVisited) "Mark as Unvisited" else "Mark as Visited") },
                            onClick = {
                                onToggleVisited()
                                menuExpanded = false
                            },
                            leadingIcon = { Icon(Icons.Default.Check, contentDescription = null) }
                        )
                        DropdownMenuItem(
                            text = { Text("Edit Activity") },
                            onClick = {
                                onEdit()
                                menuExpanded = false
                            },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) }
                        )
                        if (totalDays > 1) {
                            for (d in 1..totalDays) {
                                if (d != activity.dayNumber) {
                                    DropdownMenuItem(
                                        text = { Text("Move to Day $d") },
                                        onClick = {
                                            onMoveToDay(d)
                                            menuExpanded = false
                                        },
                                        leadingIcon = { Icon(Icons.Default.ArrowForward, contentDescription = null) }
                                    )
                                }
                            }
                        }
                        DropdownMenuItem(
                            text = { Text("Delete Activity", color = CoralRed500) },
                            onClick = {
                                onDelete()
                                menuExpanded = false
                            },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = CoralRed500) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Place Title & Category
            Text(
                text = activity.placeName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (activity.isVisited) Slate600 else Slate900
            )

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                Text(
                    text = activity.category,
                    fontSize = 12.sp,
                    color = OceanBlue600,
                    fontWeight = FontWeight.Medium
                )
                if (activity.locationZone.isNotBlank()) {
                    Text(
                        text = " • ${activity.locationZone}",
                        fontSize = 12.sp,
                        color = Slate600
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Description
            if (activity.description.isNotBlank()) {
                Text(
                    text = activity.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Slate600,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Metrics: Duration, Transit, Cost
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Slate100, RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = Slate600, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("~${activity.durationMinutes}m", fontSize = 12.sp, color = Slate800, fontWeight = FontWeight.Medium)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = Slate600, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("~${activity.travelTimeMinutes}m transit", fontSize = 12.sp, color = Slate800, fontWeight = FontWeight.Medium)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Payments, contentDescription = null, tint = TropicalTeal500, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        if (activity.estimatedCost > 0) "$currencySymbol${String.format(Locale.US, "%,.0f", activity.estimatedCost)}" else "Free",
                        fontSize = 12.sp,
                        color = if (activity.estimatedCost > 0) OceanBlue800 else TropicalTeal500,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // "Since you're already here..." Nearby smart suggestions
            if (activity.nearbySuggestionsJson.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = Color(0xFFFEF9C3),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lightbulb, contentDescription = null, tint = Color(0xFFCA8A04), modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Since you're already here…",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFF854D0E)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = activity.nearbySuggestionsJson,
                            fontSize = 12.sp,
                            color = Color(0xFF713F12),
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}
