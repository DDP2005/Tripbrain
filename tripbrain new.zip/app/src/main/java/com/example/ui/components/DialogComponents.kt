package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ItineraryActivityEntity
import com.example.data.model.TripEntity
import com.example.ui.theme.OceanBlue600
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate800

@Composable
fun AddExpenseDialog(
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (category: String, amount: Double, description: String) -> Unit
) {
    val categories = listOf("🍜 Food", "🚕 Transport", "🏨 Hotel", "🎟️ Activities", "🛍️ Shopping", "📦 Other")
    var selectedCategory by remember { mutableStateOf(categories[0]) }
    var amountText by remember { mutableStateOf("") }
    var descriptionText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Trip Expense", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Category", fontSize = 13.sp, color = Slate800, fontWeight = FontWeight.Medium)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = cat == selectedCategory,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = OceanBlue600,
                                selectedLabelColor = Color.White,
                                containerColor = Slate100
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount ($currencySymbol)") },
                    placeholder = { Text("e.g. 500") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("expense_amount_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = descriptionText,
                    onValueChange = { descriptionText = it },
                    label = { Text("Description") },
                    placeholder = { Text("e.g. Seafood lunch at beach shack") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("expense_desc_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 0.0
                    if (amount > 0 && descriptionText.isNotBlank()) {
                        onConfirm(selectedCategory, amount, descriptionText)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = OceanBlue600),
                modifier = Modifier.testTag("save_expense_button")
            ) {
                Text("Save Expense")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AddBookingDialog(
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (type: String, title: String, ref: String, location: String, price: Double, notes: String) -> Unit
) {
    val types = listOf("✈️ Flight", "🚆 Train", "🚌 Bus", "🏨 Hotel", "🎟️ Activity")
    var selectedType by remember { mutableStateOf(types[0]) }
    var titleText by remember { mutableStateOf("") }
    var refText by remember { mutableStateOf("") }
    var locationText by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Travel Booking", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Booking Type", fontSize = 13.sp, color = Slate800, fontWeight = FontWeight.Medium)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    types.forEach { t ->
                        FilterChip(
                            selected = t == selectedType,
                            onClick = { selectedType = t },
                            label = { Text(t, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = OceanBlue600,
                                selectedLabelColor = Color.White,
                                containerColor = Slate100
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = titleText,
                    onValueChange = { titleText = it },
                    label = { Text("Title / Provider") },
                    placeholder = { Text("e.g. Emirates EK-512 / Grand Palace Hotel") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = refText,
                        onValueChange = { refText = it },
                        label = { Text("Ref # / PNR") },
                        placeholder = { Text("e.g. 7X9K2P") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("Price ($currencySymbol)") },
                        placeholder = { Text("0") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = locationText,
                    onValueChange = { locationText = it },
                    label = { Text("Location / Terminal") },
                    placeholder = { Text("e.g. Terminal 3 Gate 14") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Notes / Instructions") },
                    placeholder = { Text("e.g. Baggage allowance 25kg, breakfast included") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (titleText.isNotBlank()) {
                        val price = priceText.toDoubleOrNull() ?: 0.0
                        onConfirm(selectedType, titleText, refText, locationText, price, notesText)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = OceanBlue600)
            ) {
                Text("Save Booking")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AddActivityDialog(
    dayNumber: Int,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (ItineraryActivityEntity) -> Unit
) {
    var placeName by remember { mutableStateOf("") }
    var timeSlot by remember { mutableStateOf("10:00 AM") }
    var category by remember { mutableStateOf("🏛️ Sightseeing") }
    var durationText by remember { mutableStateOf("90") }
    var costText by remember { mutableStateOf("0") }
    var descText by remember { mutableStateOf("") }
    var priorityBadge by remember { mutableStateOf("⭐ MUST VISIT") }

    val badges = listOf("⭐ MUST VISIT", "🔥 VERY POPULAR", "👍 WORTH VISITING", "📸 PHOTO SPOT", "💎 HIDDEN GEM")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Activity for Day $dayNumber", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = placeName,
                    onValueChange = { placeName = it },
                    label = { Text("Place / Activity Name") },
                    placeholder = { Text("e.g. Anjuna Flea Market") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = timeSlot,
                        onValueChange = { timeSlot = it },
                        label = { Text("Time") },
                        placeholder = { Text("02:00 PM") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = durationText,
                        onValueChange = { durationText = it },
                        label = { Text("Duration (min)") },
                        placeholder = { Text("90") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Category") },
                        placeholder = { Text("🏖️ Beach / 🍜 Food") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = costText,
                        onValueChange = { costText = it },
                        label = { Text("Cost ($currencySymbol)") },
                        placeholder = { Text("0") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = descText,
                    onValueChange = { descText = it },
                    label = { Text("Short Description") },
                    placeholder = { Text("e.g. Scenic coastline walk and cafe rest") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text("Priority Badge", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    badges.forEach { b ->
                        FilterChip(
                            selected = b == priorityBadge,
                            onClick = { priorityBadge = b },
                            label = { Text(b, fontSize = 11.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (placeName.isNotBlank()) {
                        val duration = durationText.toIntOrNull() ?: 90
                        val cost = costText.toDoubleOrNull() ?: 0.0
                        onConfirm(
                            ItineraryActivityEntity(
                                tripId = 0,
                                dayNumber = dayNumber,
                                placeName = placeName,
                                category = category,
                                timeSlot = timeSlot,
                                durationMinutes = duration,
                                travelTimeMinutes = 15,
                                estimatedCost = cost,
                                description = descText,
                                priorityBadge = priorityBadge,
                                isVisited = false
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = OceanBlue600)
            ) {
                Text("Add Activity")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun EditTripDialog(
    trip: TripEntity,
    onDismiss: () -> Unit,
    onConfirm: (TripEntity) -> Unit
) {
    var destination by remember { mutableStateOf(trip.destination) }
    var budgetText by remember { mutableStateOf(trip.totalBudget.toString()) }
    var travellers by remember { mutableStateOf(trip.travellersCount) }
    var status by remember { mutableStateOf(trip.status) }

    val statuses = listOf("Planning", "Upcoming", "Ongoing", "Completed")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Trip Details", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = destination,
                    onValueChange = { destination = it },
                    label = { Text("Destination") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = budgetText,
                    onValueChange = { budgetText = it },
                    label = { Text("Total Budget (${trip.currencySymbol})") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = travellers,
                    onValueChange = { travellers = it },
                    label = { Text("Travellers Count") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("Trip Status", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    statuses.forEach { s ->
                        FilterChip(
                            selected = s == status,
                            onClick = { status = s },
                            label = { Text(s, fontSize = 12.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val budget = budgetText.toDoubleOrNull() ?: trip.totalBudget
                    onConfirm(
                        trip.copy(
                            destination = destination,
                            totalBudget = budget,
                            travellersCount = travellers,
                            status = status
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = OceanBlue600)
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
