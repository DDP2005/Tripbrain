package com.example.ui.plan

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.Luggage
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.destination.TripPlannerEngine
import com.example.data.model.BookingEntity
import com.example.data.model.BudgetAllocation
import com.example.data.model.ExpenseEntity
import com.example.data.model.ItineraryActivityEntity
import com.example.data.model.ItineraryDayEntity
import com.example.data.model.NearbyRecommendation
import com.example.data.model.PackingItemEntity
import com.example.data.model.TravelPrepItem
import com.example.data.model.TripEntity
import com.example.ui.components.ActivityTimelineCard
import com.example.ui.components.AddActivityDialog
import com.example.ui.components.AddBookingDialog
import com.example.ui.components.AddExpenseDialog
import com.example.ui.components.EditTripDialog
import com.example.ui.components.HotelBudgetSliderCard
import com.example.ui.components.MoodRecommendationsSection
import com.example.ui.theme.CoralRed100
import com.example.ui.theme.CoralRed500
import com.example.ui.theme.OceanBlue600
import com.example.ui.theme.OceanBlue800
import com.example.ui.theme.OceanBlue900
import com.example.ui.theme.SkyBlue200
import com.example.ui.theme.SkyBlue400
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.SunsetAmber100
import com.example.ui.theme.SunsetAmber500
import com.example.ui.theme.SunsetAmber600
import com.example.ui.theme.TropicalTeal100
import com.example.ui.theme.TropicalTeal500
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TripDetailScreen(
    trip: TripEntity,
    days: List<ItineraryDayEntity>,
    activities: List<ItineraryActivityEntity>,
    expenses: List<ExpenseEntity>,
    bookings: List<BookingEntity>,
    packingItems: List<PackingItemEntity>,
    prepItems: List<TravelPrepItem>,
    selectedMood: String,
    quickRecommendations: List<NearbyRecommendation>,
    onNavigateBack: () -> Unit,
    onUpdateHotelBudget: (Double) -> Unit,
    onSelectMood: (String) -> Unit,
    onToggleVisited: (ItineraryActivityEntity) -> Unit,
    onAddActivity: (ItineraryActivityEntity) -> Unit,
    onUpdateActivity: (ItineraryActivityEntity) -> Unit,
    onDeleteActivity: (ItineraryActivityEntity) -> Unit,
    onMoveActivity: (ItineraryActivityEntity, Int) -> Unit,
    onAddExpense: (category: String, amount: Double, description: String) -> Unit,
    onDeleteExpense: (ExpenseEntity) -> Unit,
    onAddBooking: (type: String, title: String, ref: String, timeMillis: Long, location: String, price: Double, notes: String) -> Unit,
    onDeleteBooking: (BookingEntity) -> Unit,
    onTogglePackingItem: (PackingItemEntity) -> Unit,
    onAddPackingItem: (name: String, category: String) -> Unit,
    onDeletePackingItem: (PackingItemEntity) -> Unit,
    onUpdateTrip: (TripEntity) -> Unit,
    onDeleteTrip: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val tabs = listOf("🗓️ Itinerary", "💰 Budget", "🧳 Packing", "🎟️ Bookings", "🌐 Travel Prep")
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var selectedDayNumber by remember { mutableIntStateOf(1) }

    var showAddActivityDialog by remember { mutableStateOf(false) }
    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var showAddBookingDialog by remember { mutableStateOf(false) }
    var showEditTripDialog by remember { mutableStateOf(false) }
    var showCustomPackingDialog by remember { mutableStateOf(false) }

    val dateFormat = remember { SimpleDateFormat("MMM d, yyyy", Locale.getDefault()) }
    val startStr = dateFormat.format(Date(trip.startDateMillis))
    val endStr = dateFormat.format(Date(trip.endDateMillis))

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(trip.destination, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("$startStr – $endStr (${trip.numDays}D/${trip.numNights}N)", fontSize = 12.sp, color = Slate600)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showEditTripDialog = true }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Trip", tint = Slate600)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF8FAFC))
        ) {
            // Top Tab Row
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = Color.White,
                contentColor = OceanBlue600,
                edgePadding = 16.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = OceanBlue600,
                        height = 3.dp
                    )
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 13.sp
                            )
                        },
                        modifier = Modifier.testTag("tab_${title.take(3)}")
                    )
                }
            }

            // Tab Content
            when (selectedTabIndex) {
                0 -> ItineraryTabContent(
                    trip = trip,
                    days = days,
                    activities = activities,
                    selectedDayNumber = selectedDayNumber,
                    selectedMood = selectedMood,
                    quickRecommendations = quickRecommendations,
                    onSelectDay = { selectedDayNumber = it },
                    onSelectMood = onSelectMood,
                    onToggleVisited = onToggleVisited,
                    onAddActivityClick = { showAddActivityDialog = true },
                    onDeleteActivity = onDeleteActivity,
                    onMoveActivity = onMoveActivity
                )
                1 -> BudgetTabContent(
                    trip = trip,
                    expenses = expenses,
                    onUpdateHotelBudget = onUpdateHotelBudget,
                    onAddExpenseClick = { showAddExpenseDialog = true },
                    onDeleteExpense = onDeleteExpense
                )
                2 -> PackingTabContent(
                    items = packingItems,
                    onToggleItem = onTogglePackingItem,
                    onDeleteItem = onDeletePackingItem,
                    onAddCustomClick = { showCustomPackingDialog = true }
                )
                3 -> BookingsTabContent(
                    bookings = bookings,
                    currencySymbol = trip.currencySymbol,
                    onAddBookingClick = { showAddBookingDialog = true },
                    onDeleteBooking = onDeleteBooking
                )
                4 -> TravelPrepTabContent(
                    trip = trip,
                    prepItems = prepItems
                )
            }
        }
    }

    // Dialogs
    if (showAddActivityDialog) {
        AddActivityDialog(
            dayNumber = selectedDayNumber,
            currencySymbol = trip.currencySymbol,
            onDismiss = { showAddActivityDialog = false },
            onConfirm = { act ->
                onAddActivity(act.copy(tripId = trip.id))
                showAddActivityDialog = false
            }
        )
    }

    if (showAddExpenseDialog) {
        AddExpenseDialog(
            currencySymbol = trip.currencySymbol,
            onDismiss = { showAddExpenseDialog = false },
            onConfirm = { cat, amt, desc ->
                onAddExpense(cat, amt, desc)
                showAddExpenseDialog = false
            }
        )
    }

    if (showAddBookingDialog) {
        AddBookingDialog(
            currencySymbol = trip.currencySymbol,
            onDismiss = { showAddBookingDialog = false },
            onConfirm = { type, title, ref, loc, price, notes ->
                onAddBooking(type, title, ref, trip.startDateMillis, loc, price, notes)
                showAddBookingDialog = false
            }
        )
    }

    if (showEditTripDialog) {
        EditTripDialog(
            trip = trip,
            onDismiss = { showEditTripDialog = false },
            onConfirm = { updated ->
                onUpdateTrip(updated)
                showEditTripDialog = false
            }
        )
    }

    if (showCustomPackingDialog) {
        var customItemName by remember { mutableStateOf("") }
        var customCategory by remember { mutableStateOf("👕 Clothes & Footwear") }
        val packingCategories = listOf("👕 Clothes & Footwear", "🪪 Documents", "🔌 Electronics", "🧴 Toiletries", "🏊 Beach & Activities", "💊 Health & First Aid")

        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showCustomPackingDialog = false },
            title = { Text("Add Packing Item", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = customItemName,
                        onValueChange = { customItemName = it },
                        label = { Text("Item Name") },
                        placeholder = { Text("e.g. Snorkel mask, Rain poncho") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Category", fontSize = 12.sp, color = Slate600)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        packingCategories.forEach { cat ->
                            FilterChip(
                                selected = cat == customCategory,
                                onClick = { customCategory = cat },
                                label = { Text(cat, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (customItemName.isNotBlank()) {
                            onAddPackingItem(customItemName.trim(), customCategory)
                            showCustomPackingDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = OceanBlue600)
                ) {
                    Text("Add Item")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomPackingDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ItineraryTabContent(
    trip: TripEntity,
    days: List<ItineraryDayEntity>,
    activities: List<ItineraryActivityEntity>,
    selectedDayNumber: Int,
    selectedMood: String,
    quickRecommendations: List<NearbyRecommendation>,
    onSelectDay: (Int) -> Unit,
    onSelectMood: (String) -> Unit,
    onToggleVisited: (ItineraryActivityEntity) -> Unit,
    onAddActivityClick: () -> Unit,
    onDeleteActivity: (ItineraryActivityEntity) -> Unit,
    onMoveActivity: (ItineraryActivityEntity, Int) -> Unit
) {
    val currentDay = days.find { it.dayNumber == selectedDayNumber }
    val dayActivities = activities.filter { it.dayNumber == selectedDayNumber }

    val visitedCount = dayActivities.count { it.isVisited }
    val totalActivities = dayActivities.size

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Day Selector Chips Row
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Select Day Schedule:", fontSize = 12.sp, color = Slate600, fontWeight = FontWeight.Medium)
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(trip.numDays) { index ->
                        val dayNum = index + 1
                        val isSelected = dayNum == selectedDayNumber
                        Surface(
                            color = if (isSelected) OceanBlue600 else Color.White,
                            shape = RoundedCornerShape(14.dp),
                            shadowElevation = if (isSelected) 4.dp else 1.dp,
                            modifier = Modifier
                                .clickable { onSelectDay(dayNum) }
                                .testTag("day_chip_$dayNum")
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "DAY $dayNum",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isSelected) Color.White else Slate800
                                )
                            }
                        }
                    }
                }
            }
        }

        // Current Day Theme Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = OceanBlue900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = currentDay?.dayTheme ?: "Day $selectedDayNumber: Highlights",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )

                        Surface(
                            color = Color(0x33FFFFFF),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "$visitedCount / $totalActivities done",
                                color = SkyBlue200,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // Timeline Activities
        if (dayActivities.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("No activities scheduled for Day $selectedDayNumber", color = Slate600, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onAddActivityClick,
                            colors = ButtonDefaults.buttonColors(containerColor = OceanBlue600)
                        ) {
                            Text("Add First Activity")
                        }
                    }
                }
            }
        } else {
            items(dayActivities, key = { it.id }) { activity ->
                ActivityTimelineCard(
                    activity = activity,
                    totalDays = trip.numDays,
                    currencySymbol = trip.currencySymbol,
                    onToggleVisited = { onToggleVisited(activity) },
                    onEdit = {},
                    onDelete = { onDeleteActivity(activity) },
                    onMoveToDay = { targetDay -> onMoveActivity(activity, targetDay) }
                )
            }
        }

        // Add Activity Button
        item {
            OutlinedButton(
                onClick = onAddActivityClick,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("add_activity_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Activity to Day $selectedDayNumber", fontWeight = FontWeight.Bold)
            }
        }

        // Mood Recommendation Section
        item {
            Spacer(modifier = Modifier.height(10.dp))
            MoodRecommendationsSection(
                selectedMood = selectedMood,
                recommendations = quickRecommendations,
                onMoodSelected = onSelectMood
            )
        }
    }
}

@Composable
fun BudgetTabContent(
    trip: TripEntity,
    expenses: List<ExpenseEntity>,
    onUpdateHotelBudget: (Double) -> Unit,
    onAddExpenseClick: () -> Unit,
    onDeleteExpense: (ExpenseEntity) -> Unit
) {
    val totalExpenses = expenses.sumOf { it.amount }
    val remainingBudget = (trip.totalBudget - totalExpenses).coerceAtLeast(0.0)
    val spendRatio = if (trip.totalBudget > 0) (totalExpenses / trip.totalBudget).toFloat().coerceIn(0f, 1f) else 0f

    val allocations = remember(trip.totalBudget, trip.hotelBudget, trip.currencySymbol) {
        TripPlannerEngine.getBudgetAllocations(trip.totalBudget, trip.hotelBudget, trip.currencySymbol)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Overall Budget Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = OceanBlue900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Total Trip Budget", color = SkyBlue200, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text(
                        text = "${trip.currencySymbol}${String.format(Locale.US, "%,.0f", trip.totalBudget)}",
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Spent so far", color = SkyBlue200, fontSize = 11.sp)
                            Text(
                                "${trip.currencySymbol}${String.format(Locale.US, "%,.0f", totalExpenses)}",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("Remaining", color = SkyBlue200, fontSize = 11.sp)
                            Text(
                                "${trip.currencySymbol}${String.format(Locale.US, "%,.0f", remainingBudget)}",
                                color = if (remainingBudget < trip.totalBudget * 0.15) SunsetAmber500 else TropicalTeal100,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { spendRatio },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp),
                        color = if (spendRatio > 0.85f) CoralRed500 else SunsetAmber500,
                        trackColor = Color(0x33FFFFFF)
                    )
                }
            }
        }

        // Interactive Hotel Budget Slider
        item {
            HotelBudgetSliderCard(
                totalBudget = trip.totalBudget,
                numNights = trip.numNights,
                currentHotelBudget = trip.hotelBudget,
                currencySymbol = trip.currencySymbol,
                onBudgetChanged = onUpdateHotelBudget
            )
        }

        // Recommended Budget Breakdown
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Smart Budget Allocation",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Slate900
                    )
                    Text(
                        text = "Tailored recommended division for your ${trip.destination} trip",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate600
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    allocations.forEach { alloc ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(alloc.category, fontSize = 13.sp, color = Slate800, fontWeight = FontWeight.Medium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(alloc.formattedAmount, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Slate900)
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = Slate100,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        alloc.percentage,
                                        fontSize = 10.sp,
                                        color = Slate600,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        HorizontalDivider(color = Slate100)
                    }
                }
            }
        }

        // Logged Expenses Header & Add Button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Expense Log (${expenses.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Slate900
                )
                Button(
                    onClick = onAddExpenseClick,
                    colors = ButtonDefaults.buttonColors(containerColor = OceanBlue600),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("add_expense_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Expense", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Expenses List
        if (expenses.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                        Text("No expenses logged yet. Tap Add Expense to track spending.", fontSize = 13.sp, color = Slate600)
                    }
                }
            }
        } else {
            items(expenses, key = { it.id }) { exp ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(exp.description, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Slate900)
                            Text(exp.category, fontSize = 12.sp, color = Slate600)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "${exp.currencySymbol}${String.format(Locale.US, "%,.0f", exp.amount)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = OceanBlue800
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            IconButton(onClick = { onDeleteExpense(exp) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CoralRed500, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PackingTabContent(
    items: List<PackingItemEntity>,
    onToggleItem: (PackingItemEntity) -> Unit,
    onDeleteItem: (PackingItemEntity) -> Unit,
    onAddCustomClick: () -> Unit
) {
    val totalCount = items.size
    val checkedCount = items.count { it.isChecked }
    val progress = if (totalCount > 0) checkedCount.toFloat() / totalCount else 0f

    val grouped = items.groupBy { it.category }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Progress Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Smart Packing Checklist", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Slate900)
                            Text("$checkedCount of $totalCount items packed", fontSize = 12.sp, color = Slate600)
                        }

                        Surface(
                            color = TropicalTeal100,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "${(progress * 100).toInt()}%",
                                color = TropicalTeal500,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp),
                        color = TropicalTeal500,
                        trackColor = Slate200
                    )
                }
            }
        }

        // Add Custom Item Button
        item {
            OutlinedButton(
                onClick = onAddCustomClick,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("add_packing_item_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Custom Packing Item", fontWeight = FontWeight.Bold)
            }
        }

        // Grouped Items
        grouped.forEach { (category, categoryItems) ->
            item {
                Text(
                    text = category,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = OceanBlue900,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            items(categoryItems, key = { it.id }) { item ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (item.isChecked) Color(0xFFF0FDF4) else Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onToggleItem(item) }
                        .testTag("packing_item_${item.id}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = item.isChecked,
                            onCheckedChange = { onToggleItem(item) },
                            colors = CheckboxDefaults.colors(checkedColor = TropicalTeal500)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = item.name,
                            fontSize = 13.sp,
                            color = if (item.isChecked) Slate600 else Slate900,
                            textDecoration = if (item.isChecked) TextDecoration.LineThrough else TextDecoration.None,
                            modifier = Modifier.weight(1f)
                        )
                        if (item.isCustom) {
                            IconButton(onClick = { onDeleteItem(item) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CoralRed500, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BookingsTabContent(
    bookings: List<BookingEntity>,
    currencySymbol: String,
    onAddBookingClick: () -> Unit,
    onDeleteBooking: (BookingEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Travel Bookings & Tickets", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Slate900)
                    Text("Flights, Trains, Buses, Stays & Activities", fontSize = 12.sp, color = Slate600)
                }

                Button(
                    onClick = onAddBookingClick,
                    colors = ButtonDefaults.buttonColors(containerColor = OceanBlue600),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("add_booking_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Booking", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (bookings.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .background(SunsetAmber100, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.ConfirmationNumber, contentDescription = null, tint = SunsetAmber600)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("No bookings added yet", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Keep all flight PNRs, hotel vouchers and tickets organized in one offline place.", fontSize = 12.sp, color = Slate600, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }
        } else {
            items(bookings, key = { it.id }) { booking ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = OceanBlue900,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = booking.bookingType,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }

                            IconButton(onClick = { onDeleteBooking(booking) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CoralRed500, modifier = Modifier.size(16.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(booking.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Slate900)

                        if (booking.bookingReference.isNotBlank()) {
                            Text("Ref / PNR: ${booking.bookingReference}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = OceanBlue600)
                        }

                        if (booking.location.isNotBlank()) {
                            Text("📍 ${booking.location}", fontSize = 12.sp, color = Slate600)
                        }

                        if (booking.price > 0) {
                            Text("Price: $currencySymbol${String.format(Locale.US, "%,.0f", booking.price)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TropicalTeal500)
                        }

                        if (booking.notes.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = Slate100,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = booking.notes,
                                    fontSize = 11.sp,
                                    color = Slate800,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TravelPrepTabContent(
    trip: TripEntity,
    prepItems: List<TravelPrepItem>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = OceanBlue900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Travel Readiness & Checklist", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Crucial preparation steps for visiting ${trip.destination}", color = SkyBlue200, fontSize = 12.sp)
                }
            }
        }

        items(prepItems) { item ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(Color(0xFFE0F2FE), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(item.icon, fontSize = 18.sp)
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Slate900)
                        Text(item.category, fontSize = 11.sp, color = OceanBlue600, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(item.description, fontSize = 12.sp, color = Slate600, lineHeight = 17.sp)
                    }
                }
            }
        }
    }
}
