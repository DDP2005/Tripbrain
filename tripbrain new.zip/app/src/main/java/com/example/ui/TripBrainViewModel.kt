package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.destination.DestinationData
import com.example.data.destination.DestinationKnowledgeEngine
import com.example.data.destination.TripPlannerEngine
import com.example.data.local.AppDatabase
import com.example.data.local.TripRepository
import com.example.data.model.BookingEntity
import com.example.data.model.BudgetAllocation
import com.example.data.model.ExpenseEntity
import com.example.data.model.ItineraryActivityEntity
import com.example.data.model.ItineraryDayEntity
import com.example.data.model.NearbyRecommendation
import com.example.data.model.PackingItemEntity
import com.example.data.model.TravelPrepItem
import com.example.data.model.TripEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

@OptIn(ExperimentalCoroutinesApi::class)
class TripBrainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: TripRepository = TripRepository(AppDatabase.getInstance(application))

    val allTrips: StateFlow<List<TripEntity>> = repository.allTrips
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Currently Selected Trip
    private val _selectedTripId = MutableStateFlow<Long?>(null)
    val selectedTripId: StateFlow<Long?> = _selectedTripId.asStateFlow()

    val currentTrip: StateFlow<TripEntity?> = _selectedTripId
        .flatMapLatest { id ->
            if (id != null) repository.getTripById(id) else flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentTripDays: StateFlow<List<ItineraryDayEntity>> = _selectedTripId
        .flatMapLatest { id ->
            if (id != null) repository.getDaysForTrip(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentTripActivities: StateFlow<List<ItineraryActivityEntity>> = _selectedTripId
        .flatMapLatest { id ->
            if (id != null) repository.getActivitiesForTrip(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentTripExpenses: StateFlow<List<ExpenseEntity>> = _selectedTripId
        .flatMapLatest { id ->
            if (id != null) repository.getExpensesForTrip(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentTripBookings: StateFlow<List<BookingEntity>> = _selectedTripId
        .flatMapLatest { id ->
            if (id != null) repository.getBookingsForTrip(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentTripPacking: StateFlow<List<PackingItemEntity>> = _selectedTripId
        .flatMapLatest { id ->
            if (id != null) repository.getPackingItemsForTrip(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Hotel Slider State for Current Trip
    private val _hotelBudgetSliderState = MutableStateFlow<Double?>(null)
    val hotelBudgetSliderState: StateFlow<Double?> = _hotelBudgetSliderState.asStateFlow()

    // Mood Recommendation State
    private val _selectedMood = MutableStateFlow("🏖️ Beach")
    val selectedMood: StateFlow<String> = _selectedMood.asStateFlow()

    private val _quickRecommendations = MutableStateFlow<List<NearbyRecommendation>>(emptyList())
    val quickRecommendations: StateFlow<List<NearbyRecommendation>> = _quickRecommendations.asStateFlow()

    // Travel Prep items for current trip
    private val _travelPrepItems = MutableStateFlow<List<TravelPrepItem>>(emptyList())
    val travelPrepItems: StateFlow<List<TravelPrepItem>> = _travelPrepItems.asStateFlow()

    init {
        // Seed default sample trip if first time launch to ensure immediate visual wow
        viewModelScope.launch {
            allTrips.collect { trips ->
                if (trips.isEmpty()) {
                    seedDefaultTrip()
                }
            }
        }
    }

    private suspend fun seedDefaultTrip() {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 14)
        val startDate = cal.timeInMillis
        cal.add(Calendar.DAY_OF_YEAR, 4)
        val endDate = cal.timeInMillis

        val defaultStyles = listOf("Beach", "Food", "Nightlife", "Sightseeing")
        val plan = TripPlannerEngine.planTrip(
            destinationName = "Goa",
            startDateMillis = startDate,
            endDateMillis = endDate,
            totalBudget = 50000.0,
            currencyCode = "INR",
            currencySymbol = "₹",
            travellers = "2",
            selectedStyles = defaultStyles
        )

        val tripId = repository.createTrip(
            trip = plan.trip,
            days = plan.days,
            activities = plan.activities,
            packingItems = plan.packingItems
        )

        // Add sample booking and expense for rich initial state
        repository.addBooking(
            BookingEntity(
                tripId = tripId,
                bookingType = "🏨 Hotel",
                title = "Taj Holiday Village Resort & Spa",
                bookingReference = "THV-84920",
                startDateTimeMillis = startDate,
                location = "Candolim, Goa",
                price = 14500.0,
                notes = "Sea view cottage booked, breakfast included."
            )
        )
        repository.addBooking(
            BookingEntity(
                tripId = tripId,
                bookingType = "✈️ Flight",
                title = "IndiGo 6E-284",
                bookingReference = "PMR89Z",
                startDateTimeMillis = startDate - 1000 * 60 * 60 * 4,
                location = "Terminal 2, Dabolim Airport",
                price = 9200.0,
                notes = "Web check-in completed, seats 14A & 14B."
            )
        )
        repository.addExpense(
            ExpenseEntity(
                tripId = tripId,
                category = "✈️ Transport",
                amount = 9200.0,
                currencySymbol = "₹",
                description = "Roundtrip Flights"
            )
        )
        repository.addExpense(
            ExpenseEntity(
                tripId = tripId,
                category = "🏨 Hotel",
                amount = 14500.0,
                currencySymbol = "₹",
                description = "Resort Deposit"
            )
        )
    }

    fun selectTrip(tripId: Long) {
        _selectedTripId.value = tripId
        _hotelBudgetSliderState.value = null
        refreshDestinationData(tripId)
    }

    private fun refreshDestinationData(tripId: Long) {
        viewModelScope.launch {
            val trip = repository.getTripByIdOnce(tripId) ?: return@launch
            val styles = trip.travelStyles.split(",").filter { it.isNotBlank() }
            val destData = DestinationKnowledgeEngine.getOrSynthesizeDestination(trip.destination, styles)
            val currencyObj = DestinationKnowledgeEngine.CURRENCIES.find { it.code.equals(trip.currencyCode, ignoreCase = true) }
                ?: DestinationKnowledgeEngine.CURRENCIES.first()

            val plan = TripPlannerEngine.planTrip(
                destinationName = trip.destination,
                startDateMillis = trip.startDateMillis,
                endDateMillis = trip.endDateMillis,
                totalBudget = trip.totalBudget,
                currencyCode = trip.currencyCode,
                currencySymbol = trip.currencySymbol,
                travellers = trip.travellersCount,
                selectedStyles = styles
            )
            _travelPrepItems.value = plan.prepItems
            updateMoodRecommendations(_selectedMood.value, destData, trip.currencySymbol, currencyObj.approximateRateToUSD)
        }
    }

    fun selectMood(mood: String) {
        _selectedMood.value = mood
        val trip = currentTrip.value ?: return
        val styles = trip.travelStyles.split(",").filter { it.isNotBlank() }
        val destData = DestinationKnowledgeEngine.getOrSynthesizeDestination(trip.destination, styles)
        val currencyObj = DestinationKnowledgeEngine.CURRENCIES.find { it.code.equals(trip.currencyCode, ignoreCase = true) }
            ?: DestinationKnowledgeEngine.CURRENCIES.first()
        updateMoodRecommendations(mood, destData, trip.currencySymbol, currencyObj.approximateRateToUSD)
    }

    private fun updateMoodRecommendations(mood: String, destData: DestinationData, symbol: String, usdRate: Double) {
        _quickRecommendations.value = TripPlannerEngine.getQuickMoodRecommendations(mood, destData, symbol, usdRate)
    }

    fun updateHotelBudget(newAmount: Double) {
        _hotelBudgetSliderState.value = newAmount
        val trip = currentTrip.value ?: return
        viewModelScope.launch {
            repository.updateTrip(trip.copy(hotelBudget = newAmount))
        }
    }

    fun createAndPlanTrip(
        destination: String,
        startDateMillis: Long,
        endDateMillis: Long,
        totalBudget: Double,
        currencyCode: String,
        currencySymbol: String,
        travellers: String,
        selectedStyles: List<String>,
        onSuccess: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val plan = TripPlannerEngine.planTrip(
                destinationName = destination,
                startDateMillis = startDateMillis,
                endDateMillis = endDateMillis,
                totalBudget = totalBudget,
                currencyCode = currencyCode,
                currencySymbol = currencySymbol,
                travellers = travellers,
                selectedStyles = selectedStyles
            )

            val newId = repository.createTrip(
                trip = plan.trip,
                days = plan.days,
                activities = plan.activities,
                packingItems = plan.packingItems
            )
            selectTrip(newId)
            onSuccess(newId)
        }
    }

    fun toggleActivityVisited(activity: ItineraryActivityEntity) {
        viewModelScope.launch {
            repository.updateActivity(activity.copy(isVisited = !activity.isVisited))
        }
    }

    fun addActivity(activity: ItineraryActivityEntity) {
        viewModelScope.launch {
            repository.addActivity(activity)
        }
    }

    fun updateActivity(activity: ItineraryActivityEntity) {
        viewModelScope.launch {
            repository.updateActivity(activity)
        }
    }

    fun deleteActivity(activity: ItineraryActivityEntity) {
        viewModelScope.launch {
            repository.deleteActivity(activity)
        }
    }

    fun moveActivityToDay(activity: ItineraryActivityEntity, targetDay: Int) {
        viewModelScope.launch {
            repository.updateActivity(activity.copy(dayNumber = targetDay))
        }
    }

    fun addExpense(category: String, amount: Double, description: String) {
        val trip = currentTrip.value ?: return
        viewModelScope.launch {
            repository.addExpense(
                ExpenseEntity(
                    tripId = trip.id,
                    category = category,
                    amount = amount,
                    currencySymbol = trip.currencySymbol,
                    description = description
                )
            )
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
        }
    }

    fun addBooking(
        type: String,
        title: String,
        reference: String,
        startDateTimeMillis: Long,
        location: String,
        price: Double,
        notes: String
    ) {
        val trip = currentTrip.value ?: return
        viewModelScope.launch {
            repository.addBooking(
                BookingEntity(
                    tripId = trip.id,
                    bookingType = type,
                    title = title,
                    bookingReference = reference,
                    startDateTimeMillis = startDateTimeMillis,
                    location = location,
                    price = price,
                    notes = notes
                )
            )
        }
    }

    fun deleteBooking(booking: BookingEntity) {
        viewModelScope.launch {
            repository.deleteBooking(booking)
        }
    }

    fun togglePackingItem(item: PackingItemEntity) {
        viewModelScope.launch {
            repository.updatePackingItem(item.copy(isChecked = !item.isChecked))
        }
    }

    fun addPackingItem(name: String, category: String) {
        val trip = currentTrip.value ?: return
        viewModelScope.launch {
            repository.addPackingItem(
                PackingItemEntity(
                    tripId = trip.id,
                    name = name,
                    category = category,
                    isChecked = false,
                    isCustom = true
                )
            )
        }
    }

    fun deletePackingItem(item: PackingItemEntity) {
        viewModelScope.launch {
            repository.deletePackingItem(item)
        }
    }

    fun deleteTrip(tripId: Long) {
        viewModelScope.launch {
            repository.deleteTripById(tripId)
            if (_selectedTripId.value == tripId) {
                _selectedTripId.value = null
            }
        }
    }

    fun updateTripDetails(trip: TripEntity) {
        viewModelScope.launch {
            repository.updateTrip(trip)
        }
    }
}
