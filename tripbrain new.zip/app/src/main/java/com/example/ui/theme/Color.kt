package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// TripBrain Modern Travel Palette
val OceanBlue600 = Color(0xFF0284C7)
val OceanBlue700 = Color(0xFF0369A1)
val OceanBlue800 = Color(0xFF075985)
val OceanBlue900 = Color(0xFF0C4A6E)
val SkyBlue200 = Color(0xFFBAE6FD)
val SkyBlue400 = Color(0xFF38BDF8)

val SunsetAmber500 = Color(0xFFF59E0B)
val SunsetAmber600 = Color(0xFFD97706)
val SunsetAmber100 = Color(0xFFFEF3C7)

val TropicalTeal500 = Color(0xFF0D9488)
val TropicalTeal100 = Color(0xFFCCFBF1)

val CoralRed500 = Color(0xFFEF4444)
val CoralRed100 = Color(0xFFFEE2E2)

val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate600 = Color(0xFF475569)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
