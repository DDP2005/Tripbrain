package com.example.ui.create

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DateRangePicker
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberDateRangePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.destination.DestinationKnowledgeEngine
import com.example.data.model.CurrencyInfo
import com.example.ui.theme.OceanBlue600
import com.example.ui.theme.OceanBlue800
import com.example.ui.theme.OceanBlue900
import com.example.ui.theme.SkyBlue200
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.SunsetAmber100
import com.example.ui.theme.SunsetAmber500
import com.example.ui.theme.SunsetAmber600
import com.example.ui.theme.TropicalTeal100
import com.example.ui.theme.TropicalTeal500
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CreateTripScreen(
    initialDestination: String = "",
    onNavigateBack: () -> Unit,
    onPlanTrip: (
        destination: String,
        startDateMillis: Long,
        endDateMillis: Long,
        totalBudget: Double,
        currencyCode: String,
        currencySymbol: String,
        travellers: String,
        selectedStyles: List<String>
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    var destinationInput by remember { mutableStateOf(initialDestination) }

    // Visual Dates State
    val initialStart = remember {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 7)
        cal.timeInMillis
    }
    val initialEnd = remember {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 12)
        cal.timeInMillis
    }

    var startDateMillis by remember { mutableStateOf(initialStart) }
    var endDateMillis by remember { mutableStateOf(initialEnd) }
    var showDateRangePickerModal by remember { mutableStateOf(false) }

    val dateFormat = remember { SimpleDateFormat("MMM d, yyyy", Locale.getDefault()) }

    val daysCount by remember(startDateMillis, endDateMillis) {
        derivedStateOf {
            val diff = (endDateMillis - startDateMillis).coerceAtLeast(0L)
            ((diff / (24 * 60 * 60 * 1000L)) + 1).toInt().coerceIn(1, 30)
        }
    }

    val nightsCount by remember(daysCount) {
        derivedStateOf { (daysCount - 1).coerceAtLeast(1) }
    }

    // Currencies & Budget State
    val currencies = DestinationKnowledgeEngine.CURRENCIES
    var selectedCurrency by remember { mutableStateOf(currencies[0]) } // Default INR
    var currencyMenuExpanded by remember { mutableStateOf(false) }
    var budgetInput by remember { mutableStateOf("50000") }

    // Quick suggestions for budget based on currency
    val budgetSuggestions = remember(selectedCurrency.code) {
        when (selectedCurrency.code) {
            "INR" -> listOf("₹25,000", "₹50,000", "₹1,00,000", "₹2,00,000")
            "USD" -> listOf("$800", "$1,500", "$3,000", "$5,000")
            "EUR" -> listOf("€750", "€1,400", "€2,800", "€4,500")
            "GBP" -> listOf("£650", "£1,200", "£2,500", "£4,000")
            "AED" -> listOf("د.إ 3,000", "د.إ 6,000", "د.إ 12,000")
            "JPY" -> listOf("¥100,000", "¥200,000", "¥400,000")
            else -> listOf("1,000", "2,500", "5,000")
        }
    }

    // Travellers Selection
    val travellerOptions = listOf("1", "2", "3", "4", "5", "6+")
    var selectedTraveller by remember { mutableStateOf("2") }

    // Travel Styles Selection (Multi-select)
    val styleOptions = listOf(
        "🌴 Relaxed", "🏖️ Beach", "🏔️ Adventure", "📸 Sightseeing",
        "🏛️ History", "🎭 Culture", "🍜 Food", "☕ Cafés",
        "🎉 Nightlife", "🛍️ Shopping", "🌿 Nature", "❤️ Romantic",
        "👨‍👩‍👧 Family", "🎢 Activities", "📸 Photography", "🧘 Wellness", "🔥 Mixed"
    )
    var selectedStyles by remember {
        mutableStateOf(setOf("🏖️ Beach", "🍜 Food", "🎉 Nightlife", "📸 Sightseeing"))
    }

    // Popular Destination Chips for instant fill
    val popularWorldwide = listOf(
        "Goa", "Tokyo", "Paris", "Dubai", "Bali", "New York", "London", "Bangkok", "Switzerland", "Kerala", "Rome", "Singapore", "Iceland"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Create New Trip", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Instant destination-specific planning", fontSize = 12.sp, color = Slate600)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            Surface(
                color = Color.White,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Button(
                        onClick = {
                            val dest = destinationInput.trim().ifEmpty { "Goa" }
                            val cleanBudgetStr = budgetInput.replace("[^0-9.]".toRegex(), "")
                            val budget = cleanBudgetStr.toDoubleOrNull() ?: 50000.0
                            val cleanStyles = selectedStyles.map { it.replace("[^a-zA-Z& ]".toRegex(), "").trim() }
                            onPlanTrip(
                                dest,
                                startDateMillis,
                                endDateMillis,
                                budget,
                                selectedCurrency.code,
                                selectedCurrency.symbol,
                                selectedTraveller,
                                cleanStyles
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = OceanBlue600),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("plan_my_trip_button")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = SunsetAmber500)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "✨ PLAN MY TRIP",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF8FAFC)),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. DESTINATION SECTION
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(Color(0xFFE0F2FE), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = OceanBlue600, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Destination", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Slate900)
                                Text("Worldwide city, region or country", fontSize = 12.sp, color = Slate600)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = destinationInput,
                            onValueChange = { destinationInput = it },
                            placeholder = { Text("e.g. Goa, Tokyo, Paris, Dubai, Bali…") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = OceanBlue600) },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("destination_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text("Quick Worldwide Pick:", fontSize = 12.sp, color = Slate600, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(popularWorldwide) { city ->
                                FilterChip(
                                    selected = destinationInput.equals(city, ignoreCase = true),
                                    onClick = { destinationInput = city },
                                    label = { Text(city, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = OceanBlue900,
                                        selectedLabelColor = Color.White,
                                        containerColor = Slate100
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // 2. VISUAL DATES PICKER SECTION
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(SunsetAmber100, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.DateRange, contentDescription = null, tint = SunsetAmber600, modifier = Modifier.size(20.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Trip Dates", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Slate900)
                                    Text("Visual calendar selection", fontSize = 12.sp, color = Slate600)
                                }
                            }

                            Surface(
                                color = TropicalTeal100,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = "$daysCount Days / $nightsCount Nights",
                                    color = TropicalTeal500,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Touch-friendly interactive Date Card
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Slate100,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showDateRangePickerModal = true }
                                .testTag("open_date_picker_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Start Date", fontSize = 11.sp, color = Slate600)
                                    Text(dateFormat.format(Date(startDateMillis)), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Slate900)
                                }

                                Text("➔", fontSize = 16.sp, color = OceanBlue600)

                                Column(horizontalAlignment = Alignment.End) {
                                    Text("End Date", fontSize = 11.sp, color = Slate600)
                                    Text(dateFormat.format(Date(endDateMillis)), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Slate900)
                                }

                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(OceanBlue600, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = "Pick Dates", tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "💡 Tap the dates card to open full interactive calendar range picker.",
                            fontSize = 11.sp,
                            color = Slate600
                        )
                    }
                }
            }

            // 3. BUDGET & CURRENCY SECTION
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(TropicalTeal100, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Payments, contentDescription = null, tint = TropicalTeal500, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Total Trip Budget", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Slate900)
                                Text("What is your total target budget?", fontSize = 12.sp, color = Slate600)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Currency Selector Dropdown
                            Box {
                                OutlinedButton(
                                    onClick = { currencyMenuExpanded = true },
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.height(56.dp)
                                ) {
                                    Text(
                                        "${selectedCurrency.code} (${selectedCurrency.symbol})",
                                        fontWeight = FontWeight.Bold,
                                        color = OceanBlue800
                                    )
                                }

                                DropdownMenu(
                                    expanded = currencyMenuExpanded,
                                    onDismissRequest = { currencyMenuExpanded = false }
                                ) {
                                    currencies.forEach { curr ->
                                        DropdownMenuItem(
                                            text = { Text("${curr.code} - ${curr.name} (${curr.symbol})") },
                                            onClick = {
                                                selectedCurrency = curr
                                                currencyMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Budget Input
                            OutlinedTextField(
                                value = budgetInput,
                                onValueChange = { budgetInput = it },
                                label = { Text("Budget (${selectedCurrency.symbol})") },
                                placeholder = { Text("50000") },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("budget_input")
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Quick budget chips
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            budgetSuggestions.forEach { suggestion ->
                                val cleanNum = suggestion.replace("[^0-9]".toRegex(), "")
                                FilterChip(
                                    selected = budgetInput == cleanNum,
                                    onClick = { budgetInput = cleanNum },
                                    label = { Text(suggestion, fontSize = 12.sp) }
                                )
                            }
                        }
                    }
                }
            }

            // 4. TRAVELLERS SELECTION
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Number of Travellers", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Slate900)
                        Text("Quick selection", fontSize = 12.sp, color = Slate600)

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            travellerOptions.forEach { opt ->
                                val isSelected = opt == selectedTraveller
                                Surface(
                                    color = if (isSelected) OceanBlue600 else Slate100,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clickable { selectedTraveller = opt }
                                        .testTag("traveller_chip_$opt")
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = opt,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = if (isSelected) Color.White else Slate800
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 5. TRAVEL STYLE (MULTI-SELECT)
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Travel Style & Interests", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Slate900)
                        Text("Select all that match your dream experience (Multiple)", fontSize = 12.sp, color = Slate600)

                        Spacer(modifier = Modifier.height(12.dp))

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            styleOptions.forEach { style ->
                                val isSelected = selectedStyles.contains(style)
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        selectedStyles = if (isSelected) {
                                            selectedStyles - style
                                        } else {
                                            selectedStyles + style
                                        }
                                    },
                                    label = {
                                        Text(
                                            text = style,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 13.sp
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = OceanBlue600,
                                        selectedLabelColor = Color.White,
                                        containerColor = Slate100,
                                        labelColor = Slate800
                                    ),
                                    shape = RoundedCornerShape(20.dp),
                                    modifier = Modifier.testTag("style_chip_$style")
                                )
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    // Modal Date Range Picker Dialog
    if (showDateRangePickerModal) {
        val dateRangePickerState = rememberDateRangePickerState(
            initialSelectedStartDateMillis = startDateMillis,
            initialSelectedEndDateMillis = endDateMillis
        )

        DatePickerDialog(
            onDismissRequest = { showDateRangePickerModal = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        dateRangePickerState.selectedStartDateMillis?.let { s ->
                            startDateMillis = s
                        }
                        dateRangePickerState.selectedEndDateMillis?.let { e ->
                            endDateMillis = e
                        }
                        showDateRangePickerModal = false
                    }
                ) {
                    Text("Apply Dates", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDateRangePickerModal = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DateRangePicker(
                state = dateRangePickerState,
                title = { Text("Select Travel Dates", modifier = Modifier.padding(16.dp), fontWeight = FontWeight.Bold) },
                headline = {
                    val s = dateRangePickerState.selectedStartDateMillis
                    val e = dateRangePickerState.selectedEndDateMillis
                    val text = if (s != null && e != null) {
                        "${dateFormat.format(Date(s))} – ${dateFormat.format(Date(e))}"
                    } else "Select start and end dates"
                    Text(text, modifier = Modifier.padding(horizontal = 16.dp), fontSize = 14.sp)
                }
            )
        }
    }
}
